
package Component.CFXW_client;

import net.alexdieu.minecraft.gui.theme.CFXW.CFXWTheme;

import Component.CFXW_client.analytics.AnalyticsManager;
import Component.CFXW_client.chat.ChatManager;
import Component.CFXW_client.commands.CmdManager;
import Component.CFXW_client.events.EventManager;
import Component.CFXW_client.files.FileManager;
import Component.CFXW_client.font.Fonts;
import Component.CFXW_client.gui.GuiManager;
import Component.CFXW_client.hooks.FrameHook;
import Component.CFXW_client.mods.ModManager;
import Component.CFXW_client.navigator.Navigator;
import Component.CFXW_client.options.FriendsList;
import Component.CFXW_client.options.KeybindManager;
import Component.CFXW_client.options.OptionsManager;
import Component.CFXW_client.special.SpfManager;
import Component.CFXW_client.update.Updater;

public enum CFXWClient
{
	INSTANCE;
	
	public static final String VERSION = "2.20.1";
	public boolean startupMessageDisabled = false;
	
	public AnalyticsManager analytics;
	public ChatManager chat;
	public CmdManager commands;
	public EventManager events;
	public FileManager files;
	public FriendsList friends;
	public GuiManager gui;
	public ModManager mods;
	public Navigator navigator;
	public KeybindManager keybinds;
	public OptionsManager options;
	public SpfManager special;
	public Updater updater;
	
	public void startClient()
	{
		events = new EventManager();
		mods = new ModManager();
		gui = new GuiManager();
		commands = new CmdManager();
		special = new SpfManager();
		files = new FileManager();
		updater = new Updater();
		chat = new ChatManager();
		keybinds = new KeybindManager();
		options = new OptionsManager();
		friends = new FriendsList();
		navigator = new Navigator();
		
		files.init();
		navigator.sortFeatures();
		Fonts.loadFonts();
		gui.setTheme(new CFXWtheme());
		gui.setup();
		updater.checkForUpdate();
		analytics =
			new AnalyticsManager("UA-52838431-5", "https://github.com/alexdieu?tab=followers");
		files.saveOptions();
		
		FrameHook.maximize();
	}
}
