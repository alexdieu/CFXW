
package component.CFXW_client.commands;

import net.minecraft.entity.EntityLivingBase;
import component.CFXW_client.utils.EntityUtils;

@Cmd.Info(help = "Toggles Follow or makes it target a specific entity.",
	name = "follow",
	syntax = {"[<entity>]"})
public class FollowCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length > 1)
			syntaxError();
		if(args.length == 0)
			CFXW.mods.followMod.toggle();
		else
		{
			if(CFXW.mods.followMod.isEnabled())
				CFXW.mods.followMod.setEnabled(false);
			EntityLivingBase entity = EntityUtils.searchEntityByName(args[0]);
			if(entity == null)
				error("Entity \"" + args[0] + "\" could not be found.");
			CFXW.mods.followMod.setEnabled(true);
			CFXW.mods.followMod.setEntity(entity);
		}
	}
}
