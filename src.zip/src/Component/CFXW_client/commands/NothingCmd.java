
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.ChatOutputEvent;

@Info(help = "Does nothing. Useful for scripting.",
	name = "nothing",
	syntax = {})
public class NothingCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{	
		
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Do Nothing";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".nothing", true));
	}
}
