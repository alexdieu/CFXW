
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.ChatOutputEvent;
import component.CFXW_client.mods.Mod;
import component.CFXW_client.special.Spf;

@Info(help = "Shows the feature count and some over statistics.",
	name = "features",
	syntax = {})
public class FeaturesCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 0)
			syntaxError();
		
		CFXW.chat.message("> All features: "
			+ CFXW.navigator.countAllFeatures());
		CFXW.chat.message("> Mods: " + CFXW.mods.countMods());
		CFXW.chat.message("> Commands: " + CFXW.commands.countCommands());
		CFXW.chat.message("> Special features: "
			+ CFXW.special.countFeatures());
		int settings = 0, bypasses = 0;
		for(Mod mod : CFXW.mods.getAllMods())
		{
			settings += mod.getSettings().size();
			if(mod.getClass().getAnnotation(Mod.Info.class).noCheatCompatible())
				bypasses++;
		}
		CFXW.chat.message("> NoCheat bypasses (mods only): " + bypasses);
		for(Cmd cmd : CFXW.commands.getAllCommands())
			settings += cmd.getSettings().size();
		for(Spf spf : CFXW.special.getAllFeatures())
			settings += spf.getSettings().size();
		CFXW.chat.message("> Settings: " + settings);
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Show Statistics";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".features", true));
	}
}
