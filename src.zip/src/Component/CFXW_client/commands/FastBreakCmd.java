
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Changes the settings of FastBreak.",
	name = "fastbreak",
	syntax = {"mode (normal|instant)"})
public class FastBreakCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 2)
			syntaxError();
		if(args[0].toLowerCase().equals("mode"))
		{// 0=normal, 1=instant
			if(args[1].toLowerCase().equals("normal"))
				CFXW.options.fastbreakMode = 0;
			else if(args[1].toLowerCase().equals("instant"))
				CFXW.options.fastbreakMode = 1;
			else
				syntaxError();
			CFXW.files.saveOptions();
			CFXW.chat.message("FastBreak mode set to \"" + args[1] + "\".");
		}else
			syntaxError();
	}
}
