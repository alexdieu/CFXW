
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.ChatInputEvent;
import component.CFXW_client.events.listeners.ChatInputListener;

@Info(help = "Annoys a player by repeating everything he says.",
	name = "annoy",
	syntax = {"[<player>]"})
public class AnnoyCmd extends Cmd implements ChatInputListener
{
	private boolean toggled;
	private String name;
	
	@Override
	public void execute(String[] args) throws Error
	{
		toggled = !toggled;
		if(toggled)
		{
			if(args.length == 1)
			{
				name = args[0];
				CFXW.chat.message("Now annoying " + name + ".");
				if(name.equals(mc.thePlayer.getName()))
					CFXW.chat.warning("Annoying yourself is a bad idea!");
				CFXW.events.add(ChatInputListener.class, this);
			}else
			{
				toggled = false;
				syntaxError();
			}
		}else
		{
			CFXW.events.remove(ChatInputListener.class, this);
			if(name != null)
			{
				CFXW.chat.message("No longer annoying " + name + ".");
				name = null;
			}
		}
	}
	
	@Override
	public void onReceivedMessage(ChatInputEvent event)
	{
		String message = new String(event.getComponent().getUnformattedText());
		if(message.startsWith("�c[�6CFXW�c]�f "))
			return;
		if(message.startsWith("<" + name + ">") || message.contains(name + ">"))
		{
			String repeatMessage = message.substring(message.indexOf(">") + 1);
			mc.thePlayer.sendChatMessage(repeatMessage);
		}else if(message.contains("] " + name + ":")
			|| message.contains("]" + name + ":"))
		{
			String repeatMessage = message.substring(message.indexOf(":") + 1);
			mc.thePlayer.sendChatMessage(repeatMessage);
		}
	}
}
