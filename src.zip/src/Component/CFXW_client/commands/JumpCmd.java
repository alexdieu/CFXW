
package component.CFXW_client.commands;

import component.CFXW_client.events.ChatOutputEvent;

@Cmd.Info(help = "Makes you jump once.", name = "jump", syntax = {})
public class JumpCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 0)
			syntaxError();
		if(!mc.thePlayer.onGround)
			error("Can't jump in mid-air.");
		mc.thePlayer.jump();
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Jump";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".jump", true));
	}
}
