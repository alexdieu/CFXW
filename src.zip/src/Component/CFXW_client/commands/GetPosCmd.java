
package component.CFXW_client.commands;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;

import component.CFXW_client.events.ChatOutputEvent;
import net.minecraft.util.BlockPos;

@Cmd.Info(help = "Shows your current position or copies it to the clipboard.",
	name = "getpos",
	syntax = {"[copy]"})
public class GetPosCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length > 1)
			syntaxError();
		BlockPos blockpos = new BlockPos(mc.thePlayer);
		String pos =
			blockpos.getX() + " " + blockpos.getY() + " " + blockpos.getZ();
		if(args.length == 0)
			CFXW.chat.message("Position: " + pos);
		else if(args.length == 1 && args[0].equalsIgnoreCase("copy"))
		{
			Toolkit.getDefaultToolkit().getSystemClipboard()
				.setContents(new StringSelection(pos), null);
			CFXW.chat.message("Position copied to clipboard.");
		}
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Get Position";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".getpos", true));
	}
}
