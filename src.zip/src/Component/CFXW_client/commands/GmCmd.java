
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Types \"/gamemode <args>\".\nUseful for servers that don't support /gm.",
	name = "gm",
	syntax = {"<gamemode>"})
public class GmCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 1)
			syntaxError();
		mc.thePlayer.sendChatMessage("/gamemode " + args[0]);
	}
}
