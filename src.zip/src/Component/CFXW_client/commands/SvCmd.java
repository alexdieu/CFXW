
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.ChatOutputEvent;
import component.CFXW_client.hooks.ServerHook;

@Info(help = "Shows the version of the server you are currently playing on.",
	name = "sv",
	syntax = {})
public class SvCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 0)
			syntaxError();
		if(mc.isSingleplayer())
			error("Can't check server version in singleplayer.");
		CFXW.chat.message("Server version: "
			+ ServerHook.getLastServerData().gameVersion);
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Get Server Version";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".sv", true));
	}
}
