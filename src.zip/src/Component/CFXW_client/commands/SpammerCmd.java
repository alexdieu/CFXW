
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.mods.SpammerMod;
import component.CFXW_client.spam.SpamProcessor;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Changes the delay of Spammer or spams spam from a file.",
	name = "spammer",
	syntax = {"delay <delay_in_ms>", "spam <file>"})
public class SpammerCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 2)
			syntaxError();
		if(args[0].equalsIgnoreCase("delay"))
		{
			if(!MiscUtils.isInteger(args[1]))
				syntaxError();
			int newDelay = Integer.parseInt(args[1]);
			if(newDelay % 50 > 0)
				newDelay = newDelay - newDelay % 50;
			CFXW.options.spamDelay = newDelay;
			SpammerMod.updateDelaySpinner();
			CFXW.chat.message("Spammer delay set to " + newDelay + "ms.");
		}else if(args[0].equalsIgnoreCase("spam"))
			if(!SpamProcessor.runSpam(args[1]))
				CFXW.chat.error("File does not exist.");
	}
}
