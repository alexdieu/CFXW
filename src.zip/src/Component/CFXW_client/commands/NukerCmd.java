
package component.CFXW_client.commands;

import net.minecraft.block.Block;
import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.mods.NukerMod;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Changes the settings of Nuker.", name = "nuker", syntax = {
	"mode (normal|id|flat|smash)", "id <block_id>", "name <block_name>"})
public class NukerCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		NukerMod nuker = CFXW.mods.nukerMod;
		if(args.length != 2)
			syntaxError();
		else if(args[0].toLowerCase().equals("mode"))
		{
			// search mode by name
			String[] modeNames = nuker.getModes();
			String newModeName = args[1];
			int newMode = -1;
			for(int i = 0; i < modeNames.length; i++)
				if(newModeName.equals(modeNames[i].toLowerCase()))
					newMode = i;
			
			// syntax error if mode does not exist
			if(newMode == -1)
				syntaxError("Invalid mode");
			
			if(newMode != nuker.getMode())
			{
				nuker.setMode(newMode);
				CFXW.files.saveNavigatorData();
			}
			
			CFXW.chat.message("Nuker mode set to \"" + args[1] + "\".");
		}else if(args[0].equalsIgnoreCase("id") && MiscUtils.isInteger(args[1]))
		{
			if(nuker.getMode() != 1)
			{
				nuker.setMode(1);
				CFXW.files.saveNavigatorData();
				CFXW.chat.message("Nuker mode set to \"" + args[0] + "\".");
			}
			
			NukerMod.id = Integer.valueOf(args[1]);
			CFXW.chat.message("Nuker ID set to \"" + args[1] + "\".");
		}else if(args[0].equalsIgnoreCase("name"))
		{
			if(nuker.getMode() != 1)
			{
				nuker.setMode(1);
				CFXW.files.saveNavigatorData();
				CFXW.chat.message("Nuker mode set to \"" + args[0] + "\".");
			}
			
			int newId = Block.getIdFromBlock(Block.getBlockFromName(args[1]));
			if(newId == -1)
				error("The block \"" + args[1] + "\" could not be found.");
			
			NukerMod.id = newId;
			CFXW.chat.message("Nuker ID set to " + newId + " (" + args[1]
				+ ").");
		}else
			syntaxError();
	}
}
