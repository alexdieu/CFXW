
package component.CFXW_client.commands;

import net.minecraft.util.BlockPos;
import component.CFXW_client.ai.PathFinder;
import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Walks or flies you to a specific location.",
	name = "goto",
	syntax = {"<x> <y> <z>", "<entity>"})
public class GoToCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		int[] pos = argsToPos(args);
		if(Math.abs(pos[0] - mc.thePlayer.posX) > 256
			|| Math.abs(pos[2] - mc.thePlayer.posZ) > 256)
		{
			CFXW.chat.error("Goal is out of range!");
			CFXW.chat.message("Maximum range is 256 blocks.");
			return;
		}
		tk.CFXW_client.mods.GoToCmdMod.setGoal(new BlockPos(pos[0], pos[1],
			pos[2]));
		Thread thread = new Thread(new Runnable()
		{
			@Override
			public void run()
			{
				System.out.println("Finding path");
				long startTime = System.nanoTime();
				PathFinder pathFinder =
					new PathFinder(tk.CFXW_client.mods.GoToCmdMod.getGoal());
				if(pathFinder.find())
				{
					tk.CFXW_client.mods.GoToCmdMod.setPath(pathFinder
						.formatPath());
					CFXW.mods.goToCmdMod.setEnabled(true);
				}else
					CFXW.chat.error("Could not find a path.");
				System.out.println("Done after "
					+ (System.nanoTime() - startTime) / 1e6 + "ms");
			}
		});
		thread.setPriority(Thread.MIN_PRIORITY);
		thread.start();
	}
}
