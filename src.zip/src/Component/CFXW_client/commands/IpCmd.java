
package component.CFXW_client.commands;

import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.ChatOutputEvent;
import component.CFXW_client.hooks.ServerHook;

@Info(help = "Shows the IP of the server you are currently playing on or copies it to the clipboard.",
	name = "ip",
	syntax = {"[copy]"})
public class IpCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
			CFXW.chat.message("IP: " + ServerHook.getCurrentServerIP());
		else if(args[0].toLowerCase().equals("copy"))
		{
			Toolkit
				.getDefaultToolkit()
				.getSystemClipboard()
				.setContents(
					new StringSelection(ServerHook.getCurrentServerIP()), null);
			CFXW.chat.message("IP copied to clipboard.");
		}else
			syntaxError();
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "Get IP";
	}
	
	@Override
	public void doPrimaryAction()
	{
		CFXW.commands.onSentMessage(new ChatOutputEvent(".ip", true));
	}
}
