
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Clears the chat completely.", name = "clear", syntax = {})
public class ClearCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
			mc.ingameGUI.getChatGUI().clearChatMessages();
		else
			syntaxError();
	}
}
