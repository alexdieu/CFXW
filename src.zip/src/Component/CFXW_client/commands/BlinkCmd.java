
package component.CFXW_client.commands;

@Cmd.Info(help = "Enables, disables or cancels Blink.",
	name = "blink",
	syntax = {"[(on|off|cancel)]"})
public class BlinkCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length > 1)
			syntaxError();
		if(args.length == 0)
			CFXW.mods.blinkMod.toggle();
		else if(args[0].equalsIgnoreCase("on"))
		{
			if(!CFXW.mods.blinkMod.isEnabled())
				CFXW.mods.blinkMod.setEnabled(true);
		}else if(args[0].equalsIgnoreCase("off"))
			CFXW.mods.blinkMod.setEnabled(false);
		else if(args[0].equalsIgnoreCase("cancel"))
		{
			if(CFXW.mods.blinkMod.isEnabled())
				CFXW.mods.blinkMod.cancel();
		}else
			syntaxError();
	}
}
