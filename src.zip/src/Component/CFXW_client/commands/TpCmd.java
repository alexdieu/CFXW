
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Teleports you up to 100 blocks away.\nOnly works on vanilla servers!",
	name = "tp",
	syntax = {"<x> <y> <z>", "<entity>"})
public class TpCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		int[] pos = argsToPos(args);
		mc.thePlayer.setPosition(pos[0], pos[1], pos[2]);
	}
}
