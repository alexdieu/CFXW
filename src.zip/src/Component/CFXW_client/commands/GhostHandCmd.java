
package component.CFXW_client.commands;

import net.minecraft.block.Block;
import component.CFXW_client.utils.MiscUtils;

@Cmd.Info(help = "Changes the settings of GhostHand or toggles it.",
	name = "ghosthand",
	syntax = {"id <block_id>", "name <block_name>"})
public class GhostHandCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
		{
			CFXW.mods.ghostHandMod.toggle();
			CFXW.chat.message("GhostHand turned "
				+ (CFXW.mods.ghostHandMod.isEnabled() ? "on" : "off") + ".");
		}else if(args.length == 2)
		{
			if(args[0].equalsIgnoreCase("id") && MiscUtils.isInteger(args[1]))
			{
				CFXW.options.ghostHandID = Integer.valueOf(args[1]);
				CFXW.files.saveOptions();
				CFXW.chat.message("GhostHand ID set to " + args[1] + ".");
			}else if(args[0].equalsIgnoreCase("name"))
			{
				int newID =
					Block.getIdFromBlock(Block.getBlockFromName(args[1]));
				if(newID == -1)
				{
					CFXW.chat.message("The block \"" + args[1]
						+ "\" could not be found.");
					return;
				}
				CFXW.options.ghostHandID = newID;
				CFXW.files.saveOptions();
				CFXW.chat.message("GhostHand ID set to " + newID + " ("
					+ args[1] + ").");
			}else
				syntaxError();
		}else
			syntaxError();
	}
}
