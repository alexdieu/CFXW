
package component.CFXW_client.commands;

import net.minecraft.network.play.client.C01PacketChatMessage;
import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Sends a chat message, even if the message starts with a dot.",
	name = "say",
	syntax = {"<message>"},
	tags = ".legit,dots in chat,command bypass,prefix",
	tutorial = "Commands/say")
public class SayCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length > 0)
		{
			String message = args[0];
			for(int i = 1; i < args.length; i++)
				message += " " + args[i];
			mc.thePlayer.sendQueue.addToSendQueue(new C01PacketChatMessage(
				message));
		}else
			syntaxError("Message required.");
	}
}
