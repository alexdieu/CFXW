
package component.CFXW_client.hooks;

import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import component.CFXW_client.CFXWClient;
import component.CFXW_client.options.OptionsManager.Zoom;

public class ZoomHook
{
	private static float scrollLevel = CFXWClient.INSTANCE.options.zoom.level;
	
	public static float changeFovBasedOnZoom(float fov)
	{
		Zoom zoom = CFXWClient.INSTANCE.options.zoom;
		if(Keyboard.isKeyDown(zoom.keybind))
		{
			if(zoom.scroll)
			{
				int scroll = Mouse.getDWheel();
				if(scroll > 0)
					scrollLevel =
						Math.min(Math.round(scrollLevel * 11F) / 10F, 10F);
				else if(scroll < 0)
					scrollLevel =
						Math.max(Math.round(scrollLevel * 9F) / 10F, 1F);
				fov /= scrollLevel;
			}else
				fov /= zoom.level;
		}else if(scrollLevel != zoom.level)
			scrollLevel = zoom.level;
		return fov;
	}
}
