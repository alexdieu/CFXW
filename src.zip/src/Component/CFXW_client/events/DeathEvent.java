
package component.CFXW_client.events;

public class DeathEvent extends Event
{
	@Override
	public String getAction()
	{
		return "dying";
	}
	
}
