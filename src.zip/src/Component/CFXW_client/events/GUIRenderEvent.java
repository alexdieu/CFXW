
package component.CFXW_client.events;

public class GUIRenderEvent extends RenderEvent
{
	@Override
	public String getAction()
	{
		return "rendering GUI";
	}
}
