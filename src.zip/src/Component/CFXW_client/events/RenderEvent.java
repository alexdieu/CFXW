
package component.CFXW_client.events;

import net.minecraft.client.Minecraft;

public class RenderEvent extends Event
{
	@Override
	public String getAction()
	{
		return "rendering GUI";
	}
	
	@Override
	public String getComment()
	{
		String comment = "GUI screen: ";
		if(Minecraft.getMinecraft().currentScreen != null)
			comment +=
				Minecraft.getMinecraft().currentScreen.getClass()
					.getSimpleName();
		else
			comment += "null";
		return comment;
	}
}
