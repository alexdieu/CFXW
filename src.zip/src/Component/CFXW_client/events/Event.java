
package component.CFXW_client.events;

public abstract class Event
{
	public abstract String getAction();
	
	public String getComment()
	{
		return "";
	}
}
