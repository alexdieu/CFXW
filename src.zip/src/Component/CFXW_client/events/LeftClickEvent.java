
package component.CFXW_client.events;

public class LeftClickEvent extends Event
{
	@Override
	public String getAction()
	{
		return "left-clicking";
	}
}
