
package component.CFXW_client.events;

public class UpdateEvent extends Event
{
	@Override
	public String getAction()
	{
		return "updating";
	}
}
