
package Component.CFXW_client.special;

import  Component.CFXW_client.navigator.NavigatorItem;

@Spf.Info(description = "Allows you to insert links that execute commands into writable books. This can be used to\n"
	+ "trick other people (including admins) into executing commands like \"/op YourName\" or\n"
	+ "\"/kill\".",
	name = "BookHack",
	tags = "Force OP,Book Hack,OP Book,command book",
	tutorial = "Special_Features/Force_OP_(BookHack)")
public class BookHackSpf extends Spf
{
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.opSignMod, CFXW.mods.forceOpMod,
			CFXW.special.sessionStealerSpf};
	}
}
