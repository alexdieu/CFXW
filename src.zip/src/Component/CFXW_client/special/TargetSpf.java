
package component.CFXW_client.special;

import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.navigator.settings.CheckboxSetting;
import component.CFXW_client.navigator.settings.ColorsSetting;

@Spf.Info(description = "Controls what entities are targeted by other features (e.g. Killaura). Also allows you to\n"
	+ "bypass AntiAura plugins by filtering out fake entities.",
	name = "Target")
public class TargetSpf extends Spf
{
	public final CheckboxSetting players = new CheckboxSetting("Players", true);
	public final CheckboxSetting animals = new CheckboxSetting("Animals", true);
	public final CheckboxSetting monsters = new CheckboxSetting("Monsters",
		true);
	public final CheckboxSetting golems = new CheckboxSetting("Golems", true);
	
	public final CheckboxSetting sleepingPlayers = new CheckboxSetting(
		"Sleeping players", false);
	public final CheckboxSetting invisiblePlayers = new CheckboxSetting(
		"Invisible players", false);
	public final CheckboxSetting invisibleMobs = new CheckboxSetting(
		"Invisible mobs", false);
	
	public final CheckboxSetting teams = new CheckboxSetting("Teams", false);
	public final ColorsSetting teamColors = new ColorsSetting("Team Colors",
		new boolean[]{true, true, true, true, true, true, true, true, true,
			true, true, true, true, true, true, true});
	
	public TargetSpf()
	{
		settings.add(players);
		settings.add(animals);
		settings.add(monsters);
		settings.add(golems);
		
		settings.add(sleepingPlayers);
		settings.add(invisiblePlayers);
		settings.add(invisibleMobs);
		
		settings.add(teams);
		settings.add(teamColors);
	}
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.killauraMod,
			CFXW.mods.killauraLegitMod, CFXW.mods.multiAuraMod,
			CFXW.mods.clickAuraMod, CFXW.mods.triggerBotMod,
			CFXW.mods.bowAimbotMod};
	}
}
