
package complement.CFXW_client.alts;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.net.URL;
import java.net.URLConnection;
import java.net.UnknownHostException;

import complement.CFXW_client.CFXWClient;

public class SkinStealer
{
	public static String stealSkin(String name)
	{
		String reply = "";
		try
		{
			URL skinURL =
				new URL("http://skins.minecraft.net/MinecraftSkins/" + name
					+ ".png");
			URLConnection skinCon = skinURL.openConnection();
			BufferedInputStream skinputStream =
				new BufferedInputStream(skinCon.getInputStream());
			File skin =
				new File(CFXWClient.INSTANCE.files.skinDir, name + ".png");
			FileOutputStream outputStream = new FileOutputStream(skin);
			int i;
			while((i = skinputStream.read()) != -1)
				outputStream.write(i);
			outputStream.close();
			skinputStream.close();
			reply = "�a�lSaved skin to CFXW/skins/" + name + ".png.";
		}catch(UnknownHostException e)
		{
			reply = "�4�lCannot contact skin server!Please report this error on github to Alexdieu";
		}catch(Exception e)
		{
			reply = "�4�lUnable to steal skin.This is a bug pls report it on github to alexdieu";
		}
		return reply;
	}
}
