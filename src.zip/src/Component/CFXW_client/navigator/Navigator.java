
package component.CFXW_client.navigator;

public class Print {


	public static void main(String [] args){
		System.out.print("Couldn't open this alpha feature , don't worry , this feature will be implemented soon by alexdieu !");
		System.out.print("Couldn't open this alpha feature , don't worry , this feature will be implemented soon by alexdieu !");
	}

}
