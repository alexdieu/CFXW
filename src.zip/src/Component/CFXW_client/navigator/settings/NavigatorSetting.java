
package component.CFXW_client.navigator.settings;

import java.util.ArrayList;

import component.CFXW_client.navigator.PossibleKeybind;
import component.CFXW_client.navigator.gui.NavigatorFeatureScreen;

import com.google.gson.JsonObject;

public interface NavigatorSetting
{
	public String getName();
	
	public void addToFeatureScreen(NavigatorFeatureScreen featureScreen);
	
	public ArrayList<PossibleKeybind> getPossibleKeybinds(String featureName);
	
	public void save(JsonObject json);
	
	public void load(JsonObject json);
	
	public void update();
}
