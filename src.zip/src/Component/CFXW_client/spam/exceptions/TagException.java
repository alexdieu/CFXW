
package component.CFXW_client.spam.exceptions;

import component.CFXW_client.spam.tag.Tag;

public class TagException extends SpamException
{
	public final Tag tag;
	
	public TagException(String message, int line, Tag tag)
	{
		super(message, line);
		this.tag = tag;
	}
	
	@Override
	public String getHelp()
	{
		return tag.getHelp();
	}
}
