
package component.CFXW_client.spam.exceptions;

import component.CFXW_client.spam.tag.Tag;

public class MissingArgumentException extends TagException
{
	public MissingArgumentException(String message, int line, Tag tag)
	{
		super(message, line, tag);
	}
}
