
package component.CFXW_client.spam.tag;

import java.util.ArrayList;

import component.CFXW_client.spam.exceptions.InvalidTagException;
import component.CFXW_client.spam.exceptions.SpamException;
import component.CFXW_client.spam.tag.tags.Random;
import component.CFXW_client.spam.tag.tags.Repeat;
import component.CFXW_client.spam.tag.tags.Var;

public class TagManager
{
	private final ArrayList<Tag> activeTags = new ArrayList<Tag>();
	
	public Tag getTagByName(String name, int line) throws SpamException
	{
		for(int i = 0; i < activeTags.size(); i++)
			if(activeTags.get(i).getName().equals(name))
				return activeTags.get(i);
		throw new InvalidTagException(name, line);
	}
	
	public ArrayList<Tag> getActiveTags()
	{
		return activeTags;
	}
	
	public String process(TagData tagData) throws SpamException
	{
		Tag tag = getTagByName(tagData.getTagName(), tagData.getTagLine());
		String processedTag = tag.process(tagData);
		return processedTag;
	}
	
	public TagManager()
	{
		activeTags.add(new Random());
		activeTags.add(new Repeat());
		activeTags.add(new Var());
	}
}
