
package component.CFXW_client.options;

import java.util.TreeSet;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import component.CFXW_client.CFXWClient;

public class FriendsList extends TreeSet<String>
{
	public void middleClick(Entity entityHit)
	{
		if(entityHit != null && entityHit instanceof EntityPlayer)
		{
			CFXWClient CFXW = CFXWClient.INSTANCE;
			if(CFXW.options.middleClickFriends)
			{
				FriendsList friends = CFXW.friends;
				String entityName = entityHit.getName();
				if(friends.contains(entityName))
					friends.remove(entityName);
				else
					friends.add(entityName);
				CFXW.files.saveFriends();
			}
		}
	}
}
