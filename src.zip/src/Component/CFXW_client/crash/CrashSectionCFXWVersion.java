
package component.CFXW_client.crash;

import java.util.concurrent.Callable;

import component.CFXW_client.CFXWClient;

public class CrashSectionCFXWVersion implements Callable
{
	@Override
	public String call()
	{
		return CFXWClient.VERSION
			+ " (latest: "
			+ (CFXWClient.INSTANCE.updater.getLatestVersion() == null
				? "unknown what ? Send your report : https://github.com/alexdieu/CFXW/issues" : CFXWClient.INSTANCE.updater.getLatestVersion())
			+ ")";
	}
}
