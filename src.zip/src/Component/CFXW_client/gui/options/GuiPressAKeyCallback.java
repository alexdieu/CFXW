
package component.CFXW_client.gui.options;

public interface GuiPressAKeyCallback
{
	public void setKey(String key);
}
