
package component.CFXW_client.gui.options;

import java.util.ArrayList;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import component.CFXW_client.CFXWClient;
import component.CFXW_client.gui.options.keybinds.GuiKeybindManager;
import component.CFXW_client.gui.options.xray.GuiXRayBlocksManager;
import component.CFXW_client.gui.options.zoom.GuiZoomManager;
import component.CFXW_client.options.OptionsManager.GoogleAnalytics;
import component.CFXW_client.utils.MiscUtils;

import com.google.common.collect.Lists;

public class GuiCFXWOptions extends GuiScreen
{
	private GuiScreen prevMenu;
	private String[] modListModes = {"Auto", "Count", "Hidden"};
	private String[] toolTips =
		{
			"",
			"Add/remove friends by clicking them with\n"
				+ "the middle mouse button.",
			"How the mod list under the CFXW logo\n"
				+ "should be displayed.\n" + "�lModes:�r\n"
				+ "�nAuto�r: Renders the whole list if it fits\n"
				+ "onto the screen.\n"
				+ "�nCount�r: Only renders the number of active\n" + "mods.\n"
				+ "�nHidden�r: Renders nothing.",
			"Automatically maximizes the Minecraft window.\n"
				+ "Windows & Linux only!",
			"Whether or not the CFXW News should be\n"
				+ "shown in the main menu.",
			"Sends anonymous usage statistics that\n"
				+ "help us improve the CFXW Client.",
			"Keybinds allow you to toggle any mod\n"
				+ "or command by simply pressing a\n" + "button.",
			"Manager for the blocks that X-Ray will\n" + "show.",
			"The Zoom Manager allows you to\n"
				+ "change the zoom key, how far it\n"
				+ "will zoom in and more.",
			"",
			"",
			"The official website of the CFXW\n"
				+ "Client(alexdieu's github actually). Here you can find the\n"
				+ "latest CFXW updates, news and the\n" + "CFXW wiki.",
			"The official YouTube channel of the\n"
				+ "CFXW Client. Here we post CFXW\n"
				+ "update videos, CFXW tutorials and\n" + "more.",
			"Our Twitter account shows the latest\n"
				+ "CFXW updates, news and sneak peeks in\n"
				+ "140 characters or less.",
			"The feedback network for the CFXW\n"
				+ "Client, its website, etc. This is\n"
				+ "the place to go for suggesting\n"
				+ "features and reporting bugs.", ""};
	private boolean autoMaximize;
	
	public GuiCFXWOptions(GuiScreen par1GuiScreen)
	{
		prevMenu = par1GuiScreen;
	}
	
	/**
	 * Adds the buttons (and other controls) to the screen in question.
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void initGui()
	{
		autoMaximize = CFXWClient.INSTANCE.files.loadAutoMaximize();
		buttonList.clear();
		buttonList.add(new GuiButton(0, width / 2 - 100, height / 4 + 144 - 16,
			200, 20, "Back"));
		buttonList.add(new GuiButton(1, width / 2 - 154, height / 4 + 24 - 16,
			100, 20, "Click Friends: "
				+ (CFXWClient.INSTANCE.options.middleClickFriends ? "ON"
					: "OFF")));
		buttonList.add(new GuiButton(2, width / 2 - 154, height / 4 + 48 - 16,
			100, 20, "Mod List: "
				+ modListModes[CFXWClient.INSTANCE.options.modListMode]));
		buttonList.add(new GuiButton(3, width / 2 - 154, height / 4 + 72 - 16,
			100, 20, "AutoMaximize: " + (autoMaximize ? "ON" : "OFF")));
		buttonList.add(new GuiButton(4, width / 2 - 154, height / 4 + 96 - 16,
			100, 20, "CFXW News: "
				+ (CFXWClient.INSTANCE.options.CFXWNews ? "ON" : "OFF")));
		buttonList.add(new GuiButton(5, width / 2 - 154, height / 4 + 120 - 16,
			100, 20, "Analytics: "
				+ (CFXWClient.INSTANCE.options.google_analytics.enabled ? "ON"
					: "OFF")));
		buttonList.add(new GuiButton(6, width / 2 - 50, height / 4 + 24 - 16,
			100, 20, "Keybinds"));
		buttonList.add(new GuiButton(7, width / 2 - 50, height / 4 + 48 - 16,
			100, 20, "X-Ray Blocks"));
		buttonList.add(new GuiButton(8, width / 2 - 50, height / 4 + 72 - 16,
			100, 20, "Zoom"));
		// this.buttonList.add(new GuiButton(9, this.width / 2 - 50, this.height
		// / 4 + 96 - 16, 100, 20, "???"));
		// this.buttonList.add(new GuiButton(10, this.width / 2 - 50,
		// this.height / 4 + 120 - 16, 100, 20, "???"));
		buttonList.add(new GuiButton(11, width / 2 + 54, height / 4 + 24 - 16,
			100, 20, "CFXW Website"));
		buttonList.add(new GuiButton(12, width / 2 + 54, height / 4 + 48 - 16,
			100, 20, "CFXW on YouTube"));
		buttonList.add(new GuiButton(13, width / 2 + 54, height / 4 + 72 - 16,
			100, 20, "CFXW on Twitter"));
		buttonList.add(new GuiButton(14, width / 2 + 54, height / 4 + 96 - 16,
			100, 20, "CFXW Feedback"));
		// buttonList.add(new GuiButton(15, width / 2 + 54, height / 4 + 120 -
		// 16, 100, 20, "???"));
		((GuiButton)buttonList.get(3)).enabled = !Minecraft.isRunningOnMac;
	}
	
	@Override
	protected void actionPerformed(GuiButton clickedButton)
	{
		if(clickedButton.enabled)
			if(clickedButton.id == 0)
				mc.displayGuiScreen(prevMenu);
			else if(clickedButton.id == 1)
			{// Click Friends
				CFXWClient.INSTANCE.options.middleClickFriends =
					!CFXWClient.INSTANCE.options.middleClickFriends;
				clickedButton.displayString =
					"Click Friends: "
						+ (CFXWClient.INSTANCE.options.middleClickFriends
							? "ON" : "OFF");
				CFXWClient.INSTANCE.files.saveOptions();
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"click friends",
					CFXWClient.INSTANCE.options.middleClickFriends ? "ON"
						: "OFF");
			}else if(clickedButton.id == 2)
			{// Mod List
				CFXWClient.INSTANCE.options.modListMode++;
				if(CFXWClient.INSTANCE.options.modListMode > 2)
					CFXWClient.INSTANCE.options.modListMode = 0;
				clickedButton.displayString =
					"Mod List: "
						+ modListModes[CFXWClient.INSTANCE.options.modListMode];
				CFXWClient.INSTANCE.files.saveOptions();
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"mod list",
					modListModes[CFXWClient.INSTANCE.options.modListMode]);
			}else if(clickedButton.id == 3)
			{// AutoMaximize
				autoMaximize = !autoMaximize;
				clickedButton.displayString =
					"AutoMaximize: " + (autoMaximize ? "ON" : "OFF");
				CFXWClient.INSTANCE.files.saveAutoMaximize(autoMaximize);
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"automaximize", autoMaximize ? "ON" : "OFF");
			}else if(clickedButton.id == 4)
			{// CFXW News
				CFXWClient.INSTANCE.options.CFXWNews =
					!CFXWClient.INSTANCE.options.CFXWNews;
				clickedButton.displayString =
					"CFXW News: "
						+ (CFXWClient.INSTANCE.options.CFXWNews ? "ON"
							: "OFF");
				CFXWClient.INSTANCE.files.saveOptions();
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"CFXW news", CFXWClient.INSTANCE.options.CFXWNews ? "ON"
						: "OFF");
			}else if(clickedButton.id == 5)
			{// Analytics
				GoogleAnalytics analytics =
					CFXWClient.INSTANCE.options.google_analytics;
				if(analytics.enabled)
					CFXWClient.INSTANCE.analytics.trackEvent("options",
						"analytics", "disable");
				analytics.enabled = !analytics.enabled;
				if(analytics.enabled)
					CFXWClient.INSTANCE.analytics.trackEvent("options",
						"analytics", "enable");
				clickedButton.displayString =
					"Analytics: " + (analytics.enabled ? "ON" : "OFF");
				CFXWClient.INSTANCE.files.saveOptions();
			}else if(clickedButton.id == 6)
				// Keybind Manager
				mc.displayGuiScreen(new GuiKeybindManager(this));
			else if(clickedButton.id == 7)
				// X-Ray Block Manager
				mc.displayGuiScreen(new GuiXRayBlocksManager(this));
			else if(clickedButton.id == 8)
				// Zoom Manager
				mc.displayGuiScreen(new GuiZoomManager(this));
			else if(clickedButton.id == 9)
			{	
				
			}else if(clickedButton.id == 10)
			{	
				
			}else if(clickedButton.id == 11)
			{
				MiscUtils.openLink("https://www.CFXW-client.tk/");
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"CFXW website");
			}else if(clickedButton.id == 12)
			{
				MiscUtils.openLink("https://www.CFXW-client.tk/youtube");
				CFXWClient.INSTANCE.analytics.trackEvent("options",
					"youtube channel");
			}else if(clickedButton.id == 13)
			{
				MiscUtils.openLink("https://www.CFXW-client.tk/twitter");
				CFXWClient.INSTANCE.analytics.trackEvent("options", "twitter");
			}else if(clickedButton.id == 14)
			{
				MiscUtils.openLink("https://www.CFXW-client.tk/feedback");
				CFXWClient.INSTANCE.analytics
					.trackEvent("options", "feedback");
			}else if(clickedButton.id == 15)
			{	
				
			}
	}
	
	/**
	 * Called from the main game loop to update the screen.
	 */
	@Override
	public void updateScreen()
	{
		super.updateScreen();
	}
	
	/**
	 * Draws the screen and all the components in it.
	 */
	@Override
	public void drawScreen(int par1, int par2, float par3)
	{
		drawDefaultBackground();
		drawCenteredString(fontRendererObj, "CFXW Options", width / 2, 40,
			0xffffff);
		drawCenteredString(fontRendererObj, "Settings", width / 2 - 104,
			height / 4 + 24 - 28, 0xcccccc);
		drawCenteredString(fontRendererObj, "Managers", width / 2,
			height / 4 + 24 - 28, 0xcccccc);
		drawCenteredString(fontRendererObj, "Online", width / 2 + 104,
			height / 4 + 24 - 28, 0xcccccc);
		super.drawScreen(par1, par2, par3);
		for(int i = 0; i < buttonList.size(); i++)
		{
			GuiButton button = (GuiButton)buttonList.get(i);
			if(button.isMouseOver() && !toolTips[button.id].isEmpty())
			{
				ArrayList toolTip =
					Lists.newArrayList(toolTips[button.id].split("\n"));
				drawHoveringText(toolTip, par1, par2);
				break;
			}
		}
	}
}
