
package component.CFXW_client.gui.alts;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import component.CFXW_client.CFXWClient;
import component.CFXW_client.alts.Alt;
import component.CFXW_client.alts.LoginManager;

public class GuiAltAdd extends AltEditorScreen
{
	public GuiAltAdd(GuiScreen par1GuiScreen)
	{
		super(par1GuiScreen);
	}
	
	@Override
	protected String getDoneButtonText()
	{
		return "Add";
	}
	
	@Override
	protected String getEmailBoxText()
	{
		return Minecraft.getMinecraft().session.getUsername();
	}
	
	@Override
	protected String getPasswordBoxText()
	{
		return "";
	}
	
	@Override
	protected void onDoneButtonClick(GuiButton button)
	{
		if(passwordBox.getText().length() == 0)
		{// Cracked
			GuiAltList.alts.add(new Alt(emailBox.getText()));
			displayText = "";
		}else
		{// Premium
			displayText =
				LoginManager.check(emailBox.getText(), passwordBox.getText());
			if(displayText.equals(""))
				GuiAltList.alts.add(new Alt(emailBox.getText(), passwordBox
					.getText()));
		}
		if(displayText.equals(""))
		{
			GuiAltList.sortAlts();
			CFXWClient.INSTANCE.files.saveAlts();
			mc.displayGuiScreen(prevMenu);
		}else
			errorTimer = 8;
	}
	
	@Override
	protected String getUrl()
	{
		return "/alt-manager/add";
	}
	
	@Override
	protected String getTitle()
	{
		return "Add an Alt";
	}
}
