
package component.CFXW_client.gui.alts;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import component.CFXW_client.alts.LoginManager;
import component.CFXW_client.gui.main.GuiCFXWMainMenu;

public class GuiAltLogin extends AltEditorScreen
{
	public GuiAltLogin(GuiScreen par1GuiScreen)
	{
		super(par1GuiScreen);
	}
	
	@Override
	protected String getDoneButtonText()
	{
		return "Login";
	}
	
	@Override
	protected String getEmailBoxText()
	{
		return Minecraft.getMinecraft().session.getUsername();
	}
	
	@Override
	protected String getPasswordBoxText()
	{
		return "";
	}
	
	@Override
	protected void onDoneButtonClick(GuiButton button)
	{
		if(passwordBox.getText().length() == 0)
		{
			LoginManager.changeCrackedName(emailBox.getText());
			displayText = "";
		}else
			displayText =
				LoginManager.login(emailBox.getText(), passwordBox.getText());
		if(displayText.equals(""))
			mc.displayGuiScreen(new GuiCFXWMainMenu());
		else
			errorTimer = 8;
	}
	
	@Override
	protected String getUrl()
	{
		return "/alt-manager/direct-login";
	}
	
	@Override
	protected String getTitle()
	{
		return "Login";
	}
}
