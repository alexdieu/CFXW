
package component.CFXW_client.gui.main;

import java.io.IOException;
import java.util.Map.Entry;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.GuiYesNo;
import component.CFXW_client.CFXWClient;
import component.CFXW_client.utils.MiscUtils;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

public class GuiMessage extends GuiScreen
{
	private String title;
	private String body;
	private JsonObject buttons;
	private String cancel;
	
	public GuiMessage(JsonObject json)
	{
		title = json.get("title").getAsString();
		body = json.get("body").getAsString();
		buttons = json.get("buttons").getAsJsonObject();
		cancel = json.get("cancel").getAsString();
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public void initGui()
	{
		int i = 0;
		for(Entry<String, JsonElement> entry : buttons.entrySet())
		{
			buttonList.add(new GuiButton(i, width / 2 - 100, height / 3 * 2 + i
				* 24, 200, 20, entry.getKey()));
			i++;
		}
		
		if(cancel.equals("allowed") || cancel.equals("prompt"))
			buttonList.add(new GuiButton(i, width / 2 - 50, height / 3 * 2 + i
				* 24, 100, 20, "Cancel"));
		
		CFXWClient.INSTANCE.analytics.trackPageView("/message/v"
			+ CFXWClient.VERSION, title);
	}
	
	@Override
	protected void actionPerformed(GuiButton button) throws IOException
	{
		if(button.id == buttons.entrySet().size())
		{
			if(cancel.equals("allowed"))
				mc.displayGuiScreen(new GuiCFXWMainMenu());
			else if(cancel.equals("prompt"))
				mc.displayGuiScreen(new GuiYesNo(this,
					"Are you sure you want to cancel?", "", 0));
		}else
		{
			MiscUtils.openLink(buttons.get(button.displayString).getAsString());
			CFXWClient.INSTANCE.analytics.trackEvent("message", "click", "v"
				+ CFXWClient.VERSION, button.id);
		}
	}
	
	@Override
	public void confirmClicked(boolean result, int id)
	{
		super.confirmClicked(result, id);
		
		if(result)
		{
			mc.displayGuiScreen(new GuiCFXWMainMenu());
			CFXWClient.INSTANCE.analytics.trackEvent("message", "cancel", "v"
				+ CFXWClient.VERSION);
		}else
			mc.displayGuiScreen(this);
		
	}
	
	@Override
	public void drawScreen(int mouseX, int mouseY, float partialTicks)
	{
		drawDefaultBackground();
		
		drawCenteredString(fontRendererObj, title, width / 2, height / 4,
			0xffffffff);
		
		int i = 0;
		for(String line : body.split("\n"))
		{
			drawCenteredString(fontRendererObj, line, width / 2, height / 4
				+ 16 + i * 12, 0xffffffff);
			i++;
		}
		
		super.drawScreen(mouseX, mouseY, partialTicks);
	}
}
