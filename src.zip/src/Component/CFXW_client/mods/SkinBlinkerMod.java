
package component.CFXW_client.mods;

import java.util.Set;

import net.minecraft.entity.player.EnumPlayerModelParts;
import component.CFXW_client.events.listeners.UpdateListener;

@Mod.Info(category = Mod.Category.FUN,
	description = "Makes your skin blink.\n"
		+ "Requires a skin with a jacket, a hat or something similar.",
	name = "SkinBlinker")
public class SkinBlinkerMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		if(hasTimePassedS(5f))
		{
			updateLastMS();
			Set activeParts = mc.gameSettings.func_178876_d();
			for(EnumPlayerModelParts part : EnumPlayerModelParts.values())
				mc.gameSettings
					.func_178878_a(part, !activeParts.contains(part));
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		for(EnumPlayerModelParts part : EnumPlayerModelParts.values())
			mc.gameSettings.func_178878_a(part, true);
	}
}
