
package component.CFXW_client.mods;

import java.util.ArrayList;

import net.minecraft.block.Block;
import net.minecraft.util.BlockPos;
import component.CFXW_client.events.listeners.RenderListener;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.utils.RenderUtils;

@Info(category = Category.RENDER,
	description = "Helps you to find specific blocks.\n"
		+ "Use .search id <block id> or .search name <block name>\n"
		+ "to specify it.",
	name = "Search")
public class SearchMod extends Mod implements UpdateListener, RenderListener
{
	private ArrayList<BlockPos> matchingBlocks = new ArrayList<BlockPos>();
	private int range = 50;
	private int maxBlocks = 1000;
	public boolean notify = true;
	
	@Override
	public String getRenderName()
	{
		return getName() + " [" + CFXW.options.searchID + "]";
	}
	
	@Override
	public void onEnable()
	{
		notify = true;
		CFXW.events.add(UpdateListener.class, this);
		CFXW.events.add(RenderListener.class, this);
	}
	
	@Override
	public void onRender()
	{
		for(BlockPos blockPos : matchingBlocks)
			RenderUtils.searchBox(blockPos);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		if(hasTimePassedM(3000))
		{
			matchingBlocks.clear();
			for(int y = range; y >= -range; y--)
			{
				for(int x = range; x >= -range; x--)
				{
					for(int z = range; z >= -range; z--)
					{
						int posX = (int)(mc.thePlayer.posX + x);
						int posY = (int)(mc.thePlayer.posY + y);
						int posZ = (int)(mc.thePlayer.posZ + z);
						BlockPos pos = new BlockPos(posX, posY, posZ);
						if(Block.getIdFromBlock(mc.theWorld.getBlockState(pos)
							.getBlock()) == CFXW.options.searchID)
							matchingBlocks.add(pos);
						if(matchingBlocks.size() >= maxBlocks)
							break;
					}
					if(matchingBlocks.size() >= maxBlocks)
						break;
				}
				if(matchingBlocks.size() >= maxBlocks)
					break;
			}
			if(matchingBlocks.size() >= maxBlocks && notify)
			{
				CFXW.chat.warning(getName() + " found �lA LOT�r of blocks.");
				CFXW.chat
					.message("To prevent lag, it will only show the first "
						+ maxBlocks + " blocks.");
				notify = false;
			}else if(matchingBlocks.size() < maxBlocks)
				notify = true;
			updateLastMS();
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		CFXW.events.remove(RenderListener.class, this);
	}
}
