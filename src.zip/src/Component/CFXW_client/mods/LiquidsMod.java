
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.BLOCKS,
	description = "Allows you to interact with liquid blocks.",
	name = "Liquids",
	noCheatCompatible = false,
	tutorial = "Mods/Liquids")
public class LiquidsMod extends Mod
{	
	
}
