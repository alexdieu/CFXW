
package component.CFXW_client.mods;

import net.minecraft.entity.EntityLivingBase;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;

@Info(category = Category.COMBAT,
	description = "Slower Killaura that bypasses any cheat prevention\n"
		+ "PlugIn. Not required on most NoCheat+ servers!",
	name = "KillauraLegit")
public class KillauraLegitMod extends Mod implements UpdateListener
{
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraMod, CFXW.mods.multiAuraMod,
			CFXW.mods.clickAuraMod, CFXW.mods.triggerBotMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraMod.isEnabled())
			CFXW.mods.killauraMod.setEnabled(false);
		if(CFXW.mods.multiAuraMod.isEnabled())
			CFXW.mods.multiAuraMod.setEnabled(false);
		if(CFXW.mods.clickAuraMod.isEnabled())
			CFXW.mods.clickAuraMod.setEnabled(false);
		if(CFXW.mods.tpAuraMod.isEnabled())
			CFXW.mods.tpAuraMod.setEnabled(false);
		if(CFXW.mods.triggerBotMod.isEnabled())
			CFXW.mods.triggerBotMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		EntityLivingBase en = EntityUtils.getClosestEntity(true, true);
		if(hasTimePassedS(CFXW.mods.killauraMod.yesCheatSpeed) && en != null)
			if(mc.thePlayer.getDistanceToEntity(en) <= CFXW.mods.killauraMod.yesCheatRange)
			{
				if(CFXW.mods.criticalsMod.isActive() && mc.thePlayer.onGround)
					mc.thePlayer.jump();
				if(EntityUtils.getDistanceFromMouse(en) > 55)
					EntityUtils.faceEntityClient(en);
				else
				{
					EntityUtils.faceEntityClient(en);
					mc.thePlayer.swingItem();
					mc.playerController.attackEntity(mc.thePlayer, en);
				}
				updateLastMS();
			}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
