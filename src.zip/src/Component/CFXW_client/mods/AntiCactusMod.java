
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.BLOCKS,
	description = "Protects you from cactus damage.",
	name = "AntiCactus")
public class AntiCactusMod extends Mod
{	
	
}
