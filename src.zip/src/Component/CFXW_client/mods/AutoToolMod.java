
package component.CFXW_client.mods;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import component.CFXW_client.events.listeners.LeftClickListener;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;

@Info(category = Category.BLOCKS,
	description = "Automatically uses the best tool in your hotbar to\n"
		+ "mine blocks. Tip: This works with Nuker.",
	name = "AutoTool")
public class AutoToolMod extends Mod implements LeftClickListener,
	UpdateListener
{
	private boolean isActive = false;
	private int oldSlot;
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.autoSwordMod};
	}
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(LeftClickListener.class, this);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(!mc.gameSettings.keyBindAttack.pressed && isActive)
		{
			isActive = false;
			mc.thePlayer.inventory.currentItem = oldSlot;
		}else if(isActive
			&& mc.objectMouseOver != null
			&& mc.objectMouseOver.getBlockPos() != null
			&& mc.theWorld.getBlockState(mc.objectMouseOver.getBlockPos())
				.getBlock().getMaterial() != Material.air)
			setSlot(mc.objectMouseOver.getBlockPos());
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(LeftClickListener.class, this);
		CFXW.events.remove(UpdateListener.class, this);
		isActive = false;
		mc.thePlayer.inventory.currentItem = oldSlot;
	}
	
	@Override
	public void onLeftClick()
	{
		if(mc.objectMouseOver == null
			|| mc.objectMouseOver.getBlockPos() == null)
			return;
		if(mc.theWorld.getBlockState(mc.objectMouseOver.getBlockPos())
			.getBlock().getMaterial() != Material.air)
		{
			isActive = true;
			oldSlot = mc.thePlayer.inventory.currentItem;
			setSlot(mc.objectMouseOver.getBlockPos());
		}
	}
	
	public static void setSlot(BlockPos blockPos)
	{
		float bestSpeed = 1F;
		int bestSlot = -1;
		Block block = mc.theWorld.getBlockState(blockPos).getBlock();
		for(int i = 0; i < 9; i++)
		{
			ItemStack item = mc.thePlayer.inventory.getStackInSlot(i);
			if(item == null)
				continue;
			float speed = item.getStrVsBlock(block);
			if(speed > bestSpeed)
			{
				bestSpeed = speed;
				bestSlot = i;
			}
		}
		if(bestSlot != -1)
			mc.thePlayer.inventory.currentItem = bestSlot;
	}
}
