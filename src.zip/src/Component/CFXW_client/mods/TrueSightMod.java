
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Allows you to see invisible entities.Like /vanish people or admins ",
	name = "TrueSight")
public class TrueSightMod extends Mod
{	
	
}
