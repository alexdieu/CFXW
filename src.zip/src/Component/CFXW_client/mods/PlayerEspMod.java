
package component.CFXW_client.mods;

import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import component.CFXW_client.events.listeners.RenderListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.RenderUtils;

@Info(category = Category.RENDER,
	description = "Allows you to see players through walls.",
	name = "PlayerESP")
public class PlayerEspMod extends Mod implements RenderListener
{
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.tracersMod,
			CFXW.mods.playerFinderMod, CFXW.mods.mobEspMod,
			CFXW.mods.prophuntEspMod};
	}
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(RenderListener.class, this);
	}
	
	@Override
	public void onRender()
	{
		if(CFXW.mods.arenaBrawlMod.isActive())
			return;
		for(Object entity : mc.theWorld.loadedEntityList)
			if(entity instanceof EntityPlayer
				&& !((Entity)entity).getName().equals(
					mc.getSession().getUsername()))
				RenderUtils.entityESPBox((Entity)entity, CFXW.friends
					.contains(((EntityPlayer)entity).getName()) ? 1 : 0);
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(RenderListener.class, this);
	}
}
