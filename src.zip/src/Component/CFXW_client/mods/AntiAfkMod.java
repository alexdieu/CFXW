
package component.CFXW_client.mods;

import java.util.Random;

import net.minecraft.util.BlockPos;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.utils.BlockUtils;

@Info(name = "AntiAFK",
	description = "Walks around randomly to hide you from AFK detectors.\n"
		+ "Needs 3x3 blocks of free space.",
	category = Category.MISC)
public class AntiAfkMod extends Mod implements UpdateListener
{
	private BlockPos block;
	private Random random;
	private BlockPos nextBlock;
	
	@Override
	public void onEnable()
	{
		try
		{
			block = new BlockPos(mc.thePlayer);
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		random = new Random();
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		if(hasTimePassedM(3000) || nextBlock == null)
		{
			if(block == null)
				onEnable();
			nextBlock =
				block.add(random.nextInt(3) - 1, 0, random.nextInt(3) - 1);
			updateLastMS();
		}
		BlockUtils.faceBlockClientHorizontally(nextBlock);
		if(BlockUtils.getHorizontalPlayerBlockDistance(nextBlock) > 0.75)
			mc.gameSettings.keyBindForward.pressed = true;
		else
			mc.gameSettings.keyBindForward.pressed = false;
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		mc.gameSettings.keyBindForward.pressed = false;
	}
}
