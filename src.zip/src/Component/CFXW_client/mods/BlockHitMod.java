
package component.CFXW_client.mods;

import net.minecraft.client.settings.KeyBinding;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import component.CFXW_client.events.listeners.LeftClickListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.COMBAT,
	description = "Automatically blocks whenever you hit something with a\n"
		+ "sword. Some say that you will receive less damage in PVP when doing\n"
		+ "this.",
	name = "BlockHit")
public class BlockHitMod extends Mod implements LeftClickListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(LeftClickListener.class, this);
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(LeftClickListener.class, this);
	}
	
	@Override
	public void onLeftClick()
	{
		ItemStack stack = mc.thePlayer.getCurrentEquippedItem();
		
		if(stack != null && stack.getItem() instanceof ItemSword)
			doBlock();
	}
	
	public void doBlock()
	{
		if(!isActive())
			return;
		new Thread("BlockHit")
		{
			@Override
			public void run()
			{
				KeyBinding keybindUseItem = mc.gameSettings.keyBindUseItem;
				keybindUseItem.pressed = false;
				try
				{
					Thread.sleep(50);
				}catch(InterruptedException e)
				{
					e.printStackTrace();
				}
				keybindUseItem.pressed = true;
				try
				{
					Thread.sleep(100);
				}catch(InterruptedException e)
				{
					e.printStackTrace();
				}
				keybindUseItem.pressed = false;
			}
		}.start();
	}
}
