
package component.CFXW_client.mods;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.EXPLOITS,
	description = "Makes you invisible and invincible.\n"
		+ "If you die and respawn near a certain player while\n"
		+ "this mod is enabled, that player will be unable to see\n"
		+ "you. Only works on vanilla servers!",
	name = "Invisibility",
	noCheatCompatible = false)
public class InvisibilityMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.thePlayer.getHealth() <= 0)
			if(isEnabled())
			{
				// Respawning too early for server-side invisibility
				mc.thePlayer.respawnPlayer();
				CFXW.chat.message("You should now be invisible.");
			}else
			{
				CFXW.chat.message("You are no longer invisible.");
				CFXW.events.remove(UpdateListener.class, this);
			}
	}
}
