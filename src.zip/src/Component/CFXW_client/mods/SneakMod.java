
package component.CFXW_client.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.client.C0BPacketEntityAction.Action;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MOVEMENT,
	description = "Automatically sneaks all the time.",
	name = "Sneak")
public class SneakMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(CFXW.mods.yesCheatMod.isActive())
		{
			NetHandlerPlayClient sendQueue = mc.thePlayer.sendQueue;
			sendQueue.addToSendQueue(new C0BPacketEntityAction(Minecraft
				.getMinecraft().thePlayer, Action.START_SNEAKING));
			sendQueue.addToSendQueue(new C0BPacketEntityAction(Minecraft
				.getMinecraft().thePlayer, Action.STOP_SNEAKING));
		}else
			mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(
				Minecraft.getMinecraft().thePlayer, Action.START_SNEAKING));
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		mc.gameSettings.keyBindSneak.pressed = false;
		mc.thePlayer.sendQueue.addToSendQueue(new C0BPacketEntityAction(
			mc.thePlayer, Action.STOP_SNEAKING));
	}
}
