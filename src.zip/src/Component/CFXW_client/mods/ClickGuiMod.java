
package component.CFXW_client.mods;

import net.alexdieu.minecraft.gui.util.GuiManagerDisplayScreen;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.HIDDEN, description = "", name = "ClickGUI")
public class ClickGuiMod extends Mod implements UpdateListener
{
	public ClickGuiMod()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onToggle()
	{
		if(!(mc.currentScreen instanceof GuiManagerDisplayScreen))
			mc.displayGuiScreen(new GuiManagerDisplayScreen(CFXW.gui));
	}
	
	@Override
	public void onUpdate()
	{
		CFXW.gui.update();
	}
}
