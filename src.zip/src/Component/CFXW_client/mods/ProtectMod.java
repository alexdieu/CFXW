
package component.CFXW_client.mods;

import net.minecraft.entity.EntityLivingBase;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.utils.EntityUtils;

@Info(category = Category.COMBAT,
	description = "A bot that follows the closest entity and protects it. IN ALPHA !",
	name = "Protect")
public class ProtectMod extends Mod implements UpdateListener
{
	private EntityLivingBase friend;
	private EntityLivingBase enemy;
	private float range = 6F;
	private double distanceF = 2D;
	private double distanceE = 3D;
	private float speed;
	
	@Override
	public String getRenderName()
	{
		if(friend != null)
			return "Protecting " + friend.getName();
		else
			return "Protect";
	}
	
	@Override
	public void onEnable()
	{
		friend = null;
		EntityLivingBase en = EntityUtils.getClosestEntity(false, true);
		if(en != null && mc.thePlayer.getDistanceToEntity(en) <= range)
			friend = en;
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(friend == null || friend.isDead || friend.getHealth() <= 0
			|| mc.thePlayer.getHealth() <= 0)
		{
			friend = null;
			enemy = null;
			setEnabled(false);
			return;
		}
		if(enemy != null && (enemy.getHealth() <= 0 || enemy.isDead))
			enemy = null;
		double xDistF = Math.abs(mc.thePlayer.posX - friend.posX);
		double zDistF = Math.abs(mc.thePlayer.posZ - friend.posZ);
		double xDistE = distanceE;
		double zDistE = distanceE;
		if(enemy != null && mc.thePlayer.getDistanceToEntity(enemy) <= range)
		{
			xDistE = Math.abs(mc.thePlayer.posX - enemy.posX);
			zDistE = Math.abs(mc.thePlayer.posZ - enemy.posZ);
		}else
			EntityUtils.faceEntityClient(friend);
		if((xDistF > distanceF || zDistF > distanceF)
			&& (enemy == null || mc.thePlayer.getDistanceToEntity(enemy) > range)
			|| xDistE > distanceE || zDistE > distanceE)
			mc.gameSettings.keyBindForward.pressed = true;
		else
			mc.gameSettings.keyBindForward.pressed = false;
		if(mc.thePlayer.isCollidedHorizontally && mc.thePlayer.onGround)
			mc.thePlayer.jump();
		if(mc.thePlayer.isInWater() && mc.thePlayer.posY < friend.posY)
			mc.thePlayer.motionY += 0.04;
		if(CFXW.mods.yesCheatMod.isActive())
			speed = CFXW.mods.killauraMod.yesCheatSpeed;
		else
			speed = CFXW.mods.killauraMod.normalSpeed;
		updateMS();
		if(hasTimePassedS(speed) && EntityUtils.getClosestEnemy(friend) != null)
		{
			enemy = EntityUtils.getClosestEnemy(friend);
			if(mc.thePlayer.getDistanceToEntity(enemy) <= range)
			{
				if(CFXW.mods.autoSwordMod.isActive())
					AutoSwordMod.setSlot();
				CFXW.mods.criticalsMod.doCritical();
				CFXW.mods.blockHitMod.doBlock();
				EntityUtils.faceEntityClient(enemy);
				mc.thePlayer.swingItem();
				mc.playerController.attackEntity(mc.thePlayer, enemy);
				updateLastMS();
			}
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		if(friend != null)
			mc.gameSettings.keyBindForward.pressed = false;
	}
	
	public void setFriend(EntityLivingBase friend)
	{
		this.friend = friend;
	}
}
