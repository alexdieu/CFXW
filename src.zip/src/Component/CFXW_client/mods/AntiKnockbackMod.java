
package component.CFXW_client.mods;

import net.alexdieu.minecraft.gui.component.BoundedRangeComponent.ValueDisplay;

import component.CFXW_client.navigator.settings.SliderSetting;

@Mod.Info(category = Mod.Category.COMBAT,
	description = "Protects you from getting pushed by players, mobs and\n"
		+ "fluids.",
	name = "AntiKnockback")
public class AntiKnockbackMod extends Mod
{
	public float strength = 1F;
	
	@Override
	public void initSettings()
	{
		settings.add(new SliderSetting("Strength", strength, 0.01, 1, 0.01,
			ValueDisplay.PERCENTAGE)
		{
			@Override
			public void update()
			{
				strength = (float)getValue();
			}
		});
	}
}
