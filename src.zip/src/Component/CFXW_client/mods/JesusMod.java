
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.MOVEMENT,
	description = "Allows you to walk on water.\n"
		+ "The real Jesus used this hack ~2000 years ago.\n"
		+ "Bypasses NoCheat+ if YesCheat+ is enabled.",
	name = "Jesus")
public class JesusMod extends Mod
{	
	
}
