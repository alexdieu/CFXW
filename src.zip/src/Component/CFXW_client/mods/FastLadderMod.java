
package component.CFXW_client.mods;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MOVEMENT,
	description = "Allows you to climb up ladders twice as fast.",
	name = "FastLadder")
public class FastLadderMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.thePlayer.isOnLadder() && mc.thePlayer.isCollidedHorizontally)
			mc.thePlayer.motionY = 0.25;
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
