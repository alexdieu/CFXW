
package component.CFXW_client.mods;

import java.util.Random;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;

@Mod.Info(category = Mod.Category.COMBAT,
	description = "Automatically attacks the closest valid entity while teleporting around it.It can bug and TP you under the bedrock !",
	name = "TP-Aura",
	noCheatCompatible = false,
	tags = "TpAura,tp aura,EnderAura,ender aura")
public class TpAuraMod extends Mod implements UpdateListener
{
	private Random random = new Random();
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraMod, CFXW.mods.killauraLegitMod,
			CFXW.mods.multiAuraMod, CFXW.mods.clickAuraMod,
			CFXW.mods.triggerBotMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraMod.isEnabled())
			CFXW.mods.killauraMod.setEnabled(false);
		if(CFXW.mods.killauraLegitMod.isEnabled())
			CFXW.mods.killauraLegitMod.setEnabled(false);
		if(CFXW.mods.multiAuraMod.isEnabled())
			CFXW.mods.multiAuraMod.setEnabled(false);
		if(CFXW.mods.clickAuraMod.isEnabled())
			CFXW.mods.clickAuraMod.setEnabled(false);
		if(CFXW.mods.triggerBotMod.isEnabled())
			CFXW.mods.triggerBotMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		EntityLivingBase en = EntityUtils.getClosestEntity(true, true);
		if(hasTimePassedS(CFXW.mods.killauraMod.realSpeed) && en != null)
		{
			
			if(mc.thePlayer.getDistanceToEntity(en) <= CFXW.mods.killauraMod.realRange)
			{
				mc.thePlayer.setPosition(en.posX + random.nextInt(3) * 2 - 2,
					en.posY, en.posZ + random.nextInt(3) * 2 - 2);
				if(CFXW.mods.autoSwordMod.isActive())
					AutoSwordMod.setSlot();
				CFXW.mods.criticalsMod.doCritical();
				CFXW.mods.blockHitMod.doBlock();
				EntityUtils.faceEntityPacket(en);
				mc.thePlayer.swingItem();
				mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(
					en, C02PacketUseEntity.Action.ATTACK));
				updateLastMS();
			}
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
