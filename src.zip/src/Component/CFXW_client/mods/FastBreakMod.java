
package component.CFXW_client.mods;

import net.alexdieu.minecraft.gui.component.BoundedRangeComponent.ValueDisplay;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.navigator.settings.SliderSetting;

@Info(category = Category.BLOCKS,
	description = "Allows you to break blocks faster.\n"
		+ "Tip: This works with Nuker.",
	name = "FastBreak")
public class FastBreakMod extends Mod
{
	public float speed = 2;
	
	@Override
	public void initSettings()
	{
		settings.add(new SliderSetting("Speed", speed, 1, 5, 0.05,
			ValueDisplay.DECIMAL)
		{
			@Override
			public void update()
			{
				speed = (float)getValue();
			}
		});
	}
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.fastPlaceMod,
			CFXW.mods.autoMineMod, CFXW.mods.nukerMod};
	}
}
