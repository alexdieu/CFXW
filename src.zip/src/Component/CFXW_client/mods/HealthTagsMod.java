
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Adds the health of players to their nametags.",
	name = "HealthTags")
public class HealthTagsMod extends Mod
{	
	
}
