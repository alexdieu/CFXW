
package component.CFXW_client.mods;

import static org.lwjgl.opengl.GL11.*;

import java.awt.Color;

import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.item.ItemBow;

import org.darkstorm.minecraft.gui.theme.CFXW.CFXWTheme;
import org.darkstorm.minecraft.gui.util.RenderUtil;

import component.CFXW_client.events.listeners.GUIRenderListener;
import component.CFXW_client.events.listeners.RenderListener;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;
import component.CFXW_client.utils.RenderUtils;

@Info(category = Category.COMBAT,
	description = "Automatically aims your bow at the closest entity.\n"
		+ "Tip: This works with FastBow.",
	name = "BowAimbot")
public class BowAimbotMod extends Mod implements UpdateListener,
	RenderListener, GUIRenderListener
{
	private Entity target;
	private float velocity;
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.fastBowMod};
	}
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(GUIRenderListener.class, this);
		CFXW.events.add(RenderListener.class, this);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onRender()
	{
		if(target == null)
			return;
		RenderUtils.entityESPBox(target, 3);
	}
	
	@Override
	public void onRenderGUI()
	{
		if(target == null || velocity < 0.1)
			return;
		glEnable(GL_BLEND);
		glDisable(GL_CULL_FACE);
		glDisable(GL_TEXTURE_2D);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
		RenderUtil.setColor(new Color(8, 8, 8, 128));
		ScaledResolution sr =
			new ScaledResolution(mc, mc.displayWidth, mc.displayHeight);
		int width = sr.getScaledWidth();
		int height = sr.getScaledHeight();
		String targetLocked = "Target locked";
		glBegin(GL_QUADS);
		{
			glVertex2d(width / 2 + 1, height / 2 + 1);
			glVertex2d(width
				/ 2
				+ ((CFXWTheme)CFXW.gui.getTheme()).getFontRenderer()
					.getStringWidth(targetLocked) + 4, height / 2 + 1);
			glVertex2d(
				width
					/ 2
					+ ((CFXWTheme)CFXW.gui.getTheme()).getFontRenderer()
						.getStringWidth(targetLocked) + 4,
				height
					/ 2
					+ ((CFXWTheme)CFXW.gui.getTheme()).getFontRenderer().FONT_HEIGHT);
			glVertex2d(
				width / 2 + 1,
				height
					/ 2
					+ ((CFXWTheme)CFXW.gui.getTheme()).getFontRenderer().FONT_HEIGHT);
		}
		glEnd();
		glEnable(GL_TEXTURE_2D);
		((CFXWTheme)CFXW.gui.getTheme()).getFontRenderer()
			.drawStringWithShadow(targetLocked, width / 2 + 2, height / 2,
				RenderUtil.toRGBA(Color.WHITE));
		glEnable(GL_CULL_FACE);
		glDisable(GL_BLEND);
	}
	
	@Override
	public void onUpdate()
	{
		target = null;
		if(mc.thePlayer.inventory.getCurrentItem() != null
			&& mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemBow
			&& mc.gameSettings.keyBindUseItem.pressed)
		{
			target = EntityUtils.getClosestEntity(true, true);
			aimAtTarget();
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(GUIRenderListener.class, this);
		CFXW.events.remove(RenderListener.class, this);
		CFXW.events.remove(UpdateListener.class, this);
	}
	
	private void aimAtTarget()
	{
		if(target == null)
			return;
		int bowCharge = mc.thePlayer.getItemInUseDuration();
		velocity = bowCharge / 20;
		velocity = (velocity * velocity + velocity * 2) / 3;
		if(CFXW.mods.fastBowMod.isActive())
			velocity = 1;
		if(velocity < 0.1)
		{
			if(target instanceof EntityLivingBase)
				EntityUtils.faceEntityClient((EntityLivingBase)target);
			return;
		}
		if(velocity > 1)
			velocity = 1;
		double posX =
			target.posX + (target.posX - target.prevPosX) * 5
				- mc.thePlayer.posX;
		double posY =
			target.posY + (target.posY - target.prevPosY) * 5
				+ target.getEyeHeight() - 0.15 - mc.thePlayer.posY
				- mc.thePlayer.getEyeHeight();
		double posZ =
			target.posZ + (target.posZ - target.prevPosZ) * 5
				- mc.thePlayer.posZ;
		float yaw = (float)(Math.atan2(posZ, posX) * 180 / Math.PI) - 90;
		double y2 = Math.sqrt(posX * posX + posZ * posZ);
		float g = 0.006F;
		float tmp =
			(float)(velocity * velocity * velocity * velocity - g
				* (g * (y2 * y2) + 2 * posY * (velocity * velocity)));
		float pitch =
			(float)-Math.toDegrees(Math.atan((velocity * velocity - Math
				.sqrt(tmp)) / (g * y2)));
		mc.thePlayer.rotationYaw = yaw;
		mc.thePlayer.rotationPitch = pitch;
	}
}
