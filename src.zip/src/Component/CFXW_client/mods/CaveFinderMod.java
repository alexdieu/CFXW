
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.RENDER,
	description = "Allows you to see caves through walls.",
	name = "CaveFinder")
public class CaveFinderMod extends Mod
{	
	
}
