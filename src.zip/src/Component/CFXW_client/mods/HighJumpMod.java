
package component.CFXW_client.mods;

import net.alexdieu.minecraft.gui.component.BoundedRangeComponent.ValueDisplay;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.settings.SliderSetting;

@Info(category = Category.MOVEMENT,
	description = "Makes you jump much higher.",
	name = "HighJump",
	noCheatCompatible = false)
public class HighJumpMod extends Mod
{
	public int jumpHeight = 6;
	
	@Override
	public void initSettings()
	{
		settings.add(new SliderSetting("Height", jumpHeight, 1, 100, 1,
			ValueDisplay.INTEGER)
		{
			@Override
			public void update()
			{
				jumpHeight = (int)getValue();
			}
		});
	}
}
