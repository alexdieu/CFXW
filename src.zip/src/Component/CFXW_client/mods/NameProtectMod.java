
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Hides all player names.\n"
		+ "Some YouTubers like to censor out all names in their\n" + "videos.",
	name = "NameProtect")
public class NameProtectMod extends Mod
{	
	
}
