
package component.CFXW_client.mods;

import net.minecraft.network.play.client.C03PacketPlayer;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.settings.CheckboxSetting;

@Info(category = Category.MOVEMENT,
	description = "Allows you to jump in mid-air.\n"
		+ "Looks as if you had a jetpack.",
	name = "Jetpack",
	noCheatCompatible = false)
public class JetpackMod extends Mod implements UpdateListener
{
	public final CheckboxSetting flightKickBypass = new CheckboxSetting(
		"Flight-Kick-Bypass", false);
	
	@Override
	public void onEnable()
	{
		if(CFXW.mods.flightMod.isEnabled())
			CFXW.mods.flightMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void initSettings()
	{
		settings.add(flightKickBypass);
	}
	
	@Override
	public String getRenderName()
	{
		return getName()
			+ (flightKickBypass.isChecked() ? "[Kick: "
				+ (CFXW.mods.flightMod.flyHeight <= 300 ? "Safe" : "Unsafe")
				+ "]" : "");
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		
		if(mc.gameSettings.keyBindJump.pressed)
			mc.thePlayer.jump();
		
		if(flightKickBypass.isChecked())
		{
			CFXW.mods.flightMod.updateFlyHeight();
			mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer(true));
			
			if(CFXW.mods.flightMod.flyHeight <= 290 && hasTimePassedM(500)
				|| CFXW.mods.flightMod.flyHeight > 290 && hasTimePassedM(100))
			{
				CFXW.mods.flightMod.goToGround();
				updateLastMS();
			}
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
