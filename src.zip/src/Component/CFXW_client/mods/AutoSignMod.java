
package component.CFXW_client.mods;

import net.minecraft.util.IChatComponent;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.BLOCKS,
	description = "Instantly writes whatever text you want on every sign\n"
		+ "you place. Once activated, you can write normally on\n"
		+ "one sign to specify the text for all other signs.",
	name = "AutoSign",
	noCheatCompatible = false)
public class AutoSignMod extends Mod
{
	public IChatComponent[] signText;
	
	@Override
	public void onEnable()
	{
		signText = null;
	}
}
