
package component.CFXW_client.mods;

import java.util.ArrayList;

import net.minecraft.block.Block;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Allows you to see ores through walls.",
	name = "X-Ray CFXW")
public class XRayMod extends Mod
{
	public static ArrayList<Block> xrayBlocks = new ArrayList<Block>();
	
	@Override
	public String getRenderName()
	{
		return "X-CFXW";
	}
	
	@Override
	public void onToggle()
	{
		mc.renderGlobal.loadRenderers();
	}
}
