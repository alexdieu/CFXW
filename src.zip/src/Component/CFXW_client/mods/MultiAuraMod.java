
package component.CFXW_client.mods;

import java.util.ArrayList;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;

@Info(category = Category.COMBAT,
	description = "Faster Killaura that attacks multiple entities at once.",
	name = "MultiAura",
	noCheatCompatible = false)
public class MultiAuraMod extends Mod implements UpdateListener
{
	private float range = 6F;
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraMod, CFXW.mods.killauraLegitMod,
			CFXW.mods.clickAuraMod, CFXW.mods.triggerBotMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraMod.isEnabled())
			CFXW.mods.killauraMod.setEnabled(false);
		if(CFXW.mods.killauraLegitMod.isEnabled())
			CFXW.mods.killauraLegitMod.setEnabled(false);
		if(CFXW.mods.clickAuraMod.isEnabled())
			CFXW.mods.clickAuraMod.setEnabled(false);
		if(CFXW.mods.tpAuraMod.isEnabled())
			CFXW.mods.tpAuraMod.setEnabled(false);
		if(CFXW.mods.triggerBotMod.isEnabled())
			CFXW.mods.triggerBotMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		EntityLivingBase closestEntity =
			EntityUtils.getClosestEntity(true, false);
		if(closestEntity != null
			&& mc.thePlayer.getDistanceToEntity(closestEntity) <= range)
		{
			if(CFXW.mods.autoSwordMod.isActive())
				AutoSwordMod.setSlot();
			CFXW.mods.criticalsMod.doCritical();
			CFXW.mods.blockHitMod.doBlock();
			ArrayList<EntityLivingBase> entities =
				EntityUtils.getCloseEntities(true, range);
			for(int i = 0; i < Math.min(entities.size(), 64); i++)
			{
				EntityLivingBase en = entities.get(i);
				EntityUtils.faceEntityPacket(en);
				mc.thePlayer.swingItem();
				mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(
					en, C02PacketUseEntity.Action.ATTACK));
			}
			updateLastMS();
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
