
package component.CFXW_client.mods;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;

import net.alexdieu.minecraft.gui.component.BoundedRangeComponent.ValueDisplay;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.navigator.settings.SliderSetting;
import component.CFXW_client.utils.EntityUtils;

@Info(category = Category.COMBAT,
	description = "Automatically attacks everything in your range.",
	name = "Killaura")
public class KillauraMod extends Mod implements UpdateListener
{
	public float normalSpeed = 20F;
	public float normalRange = 5F;
	public float yesCheatSpeed = 12F;
	public float yesCheatRange = 4.25F;
	public int fov = 360;
	public float realSpeed;
	public float realRange;
	
	@Override
	public void initSettings()
	{
		settings.add(new SliderSetting("Speed", normalSpeed, 2, 20, 0.1,
			ValueDisplay.DECIMAL)
		{
			@Override
			public void update()
			{
				normalSpeed = (float)getValue();
				yesCheatSpeed = Math.min(normalSpeed, 12F);
				updateSpeedAndRange();
			}
		});
		settings.add(new SliderSetting("Range", normalRange, 1, 6, 0.05,
			ValueDisplay.DECIMAL)
		{
			@Override
			public void update()
			{
				normalRange = (float)getValue();
				yesCheatRange = Math.min(normalRange, 4.25F);
				updateSpeedAndRange();
			}
		});
		settings.add(new SliderSetting("FOV", fov, 30, 360, 10,
			ValueDisplay.DEGREES)
		{
			@Override
			public void update()
			{
				fov = (int)getValue();
			}
		});
	}
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraLegitMod, CFXW.mods.multiAuraMod,
			CFXW.mods.clickAuraMod, CFXW.mods.triggerBotMod,
			CFXW.mods.criticalsMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraLegitMod.isEnabled())
			CFXW.mods.killauraLegitMod.setEnabled(false);
		if(CFXW.mods.multiAuraMod.isEnabled())
			CFXW.mods.multiAuraMod.setEnabled(false);
		if(CFXW.mods.clickAuraMod.isEnabled())
			CFXW.mods.clickAuraMod.setEnabled(false);
		if(CFXW.mods.tpAuraMod.isEnabled())
			CFXW.mods.tpAuraMod.setEnabled(false);
		if(CFXW.mods.triggerBotMod.isEnabled())
			CFXW.mods.triggerBotMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateSpeedAndRange();
		updateMS();
		EntityLivingBase en = EntityUtils.getClosestEntity(true, true);
		if(hasTimePassedS(realSpeed) && en != null)
			if(mc.thePlayer.getDistanceToEntity(en) <= realRange)
			{
				if(CFXW.mods.autoSwordMod.isActive())
					AutoSwordMod.setSlot();
				CFXW.mods.criticalsMod.doCritical();
				CFXW.mods.blockHitMod.doBlock();
				EntityUtils.faceEntityPacket(en);
				mc.thePlayer.swingItem();
				mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(
					en, C02PacketUseEntity.Action.ATTACK));
				updateLastMS();
			}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
	
	private void updateSpeedAndRange()
	{
		if(CFXW.mods.yesCheatMod.isActive())
		{
			realSpeed = yesCheatSpeed;
			realRange = yesCheatRange;
		}else
		{
			realSpeed = normalSpeed;
			realRange = normalRange;
		}
	}
}
