
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Automatically steals everything from all chests you\n"
		+ "open.",
	name = "AutoSteal")
public class AutoStealMod extends Mod
{	
	
}
