
package component.CFXW_client.mods;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;

@Info(category = Category.BLOCKS,
	description = "Allows you to place blocks 5 times faster.\n"
		+ "Tip: This can speed up AutoBuild.",
	name = "FastPlace")
public class FastPlaceMod extends Mod implements UpdateListener
{
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.fastBreakMod,
			CFXW.mods.buildRandomMod, CFXW.mods.autoBuildMod};
	}
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		mc.rightClickDelayTimer = 0;
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
