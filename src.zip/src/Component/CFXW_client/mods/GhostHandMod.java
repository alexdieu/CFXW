
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.BLOCKS,
	description = "Allows you to reach specific blocks through walls.\n"
		+ "Use .ghosthand id <block id> or .ghosthand name <block name>\n"
		+ "to specify it.",
	name = "GhostHand")
public class GhostHandMod extends Mod
{
	@Override
	public String getRenderName()
	{
		return getName() + " [" + CFXW.options.ghostHandID + "]";
	}
}
