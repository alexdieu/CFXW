
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.COMBAT,
	description = "Freezes all potion effects while you are standing still.",
	name = "PotionFreezer")
public class PotionSaverMod extends Mods
{	
	
}
