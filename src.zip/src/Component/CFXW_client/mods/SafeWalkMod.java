
package component.CFXW_client.mods;

@Mod.Info(category = Mod.Category.MOVEMENT,
	description = "Protects you from falling down as if you were sneaking!ALPHA FEATURE",
	name = "SafeWalk")
public class SafeWalkMod extends Mod
{	
	
}
