
package component.CFXW_client.mods;

import net.minecraft.network.play.client.C03PacketPlayer;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Blocks damage from catching on fire.\n"
		+ "Does NOT block damage from standing inside of fire.\n"
		+ "Requires a full hunger bar.",
	name = "AntiFire",
	noCheatCompatible = false)
public class AntiFireMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(!mc.thePlayer.capabilities.isCreativeMode && mc.thePlayer.onGround
			&& mc.thePlayer.isBurning())
			for(int i = 0; i < 100; i++)
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer());
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
