
package component.CFXW_client.mods;

import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Uses an item multiple times.\n"
		+ "This can cause a lot of lag and even crash a server.\n"
		+ "Works best with snowballs or eggs.\n"
		+ "Use the .throw command to change the amount of uses per click.",
	name = "Throw")
public class ThrowMod extends Mod implements UpdateListener
{
	@Override
	public String getRenderName()
	{
		return getName() + " [" + CFXW.options.throwAmount + "]";
	}
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if((mc.rightClickDelayTimer == 4 || CFXW.mods.fastPlaceMod.isActive())
			&& mc.gameSettings.keyBindUseItem.pressed)
		{
			if(mc.objectMouseOver == null
				|| mc.thePlayer.inventory.getCurrentItem() == null)
				return;
			for(int i = 0; i < CFXW.options.throwAmount - 1; i++)
				mc.rightClickMouse();
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
