
package component.CFXW_client.mods;

import net.minecraft.client.Minecraft;
import net.minecraft.network.play.client.C03PacketPlayer;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.FUN,
	description = "While this is active, other people will think you are\n"
		+ "headless. Looks hilarious!",
	name = "Headless")
public class HeadlessMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		mc.thePlayer.sendQueue
			.addToSendQueue(new C03PacketPlayer.C05PacketPlayerLook(Minecraft
				.getMinecraft().thePlayer.rotationYaw, 180F, Minecraft
				.getMinecraft().thePlayer.onGround));
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
