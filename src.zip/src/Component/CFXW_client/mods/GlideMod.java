
package component.CFXW_client.mods;

import net.minecraft.block.material.Material;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MOVEMENT,
	description = "Makes you fall like if you had a hang glider.",
	name = "Glide",
	noCheatCompatible = false)
public class GlideMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.thePlayer.motionY < 0 && mc.thePlayer.isAirBorne
			&& !mc.thePlayer.isInWater() && !mc.thePlayer.isOnLadder()
			&& !mc.thePlayer.isInsideOfMaterial(Material.lava))
		{
			mc.thePlayer.motionY = -0.125f;
			mc.thePlayer.jumpMovementFactor *= 1.21337f;
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
