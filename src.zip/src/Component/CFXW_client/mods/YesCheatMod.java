
package component.CFXW_client.mods;

import java.util.HashSet;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Makes other mods bypass NoCheat+(paper,or Spigot) or blocks them if\n"
		+ "they can't.",
	name = "YesCheat+")
public class YesCheatMod extends Mod
{
	private HashSet<Mod> blockedMods;
	
	@Override
	public void onEnable()
	{
		if(wurst.mods.antiMacMod.isEnabled())
			wurst.mods.antiMacMod.setEnabled(false);
		if(blockedMods == null)
		{
			blockedMods = new HashSet<>();
			for(Mod mod : wurst.mods.getAllMods())
				if(!mod.getClass().getAnnotation(Mod.Info.class)
					.noCheatCompatible())
					blockedMods.add(mod);
		}
		for(Mod mod : blockedMods)
			mod.setBlocked(true);
	}
	
	@Override
	public void onDisable()
	{
		for(Mod mod : blockedMods)
			mod.setBlocked(false);
	}
}
