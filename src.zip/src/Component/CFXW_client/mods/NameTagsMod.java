
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Changes the scale of the nametags so you can always\n"
		+ "read them.",
	name = "NameTags")
public class NameTagsMod extends Mod
{	
	
}
