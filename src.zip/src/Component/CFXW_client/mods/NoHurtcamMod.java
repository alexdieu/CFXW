
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.RENDER,
	description = "Disables the annoying effect when you get hurt.",
	name = "NoHurtcam")
public class NoHurtcamMod extends Mod
{	
	
}
