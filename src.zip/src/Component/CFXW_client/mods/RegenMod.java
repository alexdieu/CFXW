
package component.CFXW_client.mods;

import net.minecraft.network.play.client.C03PacketPlayer;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.COMBAT,
	description = "Regenerates your health 1000 times faster.\n"
		+ "Can cause unwanted \"Flying is not enabled!\" kicks.",
	name = "Regen",
	noCheatCompatible = false,
	tutorial = "Mods/Regen")
public class RegenMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(!mc.thePlayer.capabilities.isCreativeMode
			&& mc.thePlayer.getFoodStats().getFoodLevel() > 17
			&& mc.thePlayer.getHealth() < 20 && mc.thePlayer.getHealth() != 0
			&& mc.thePlayer.onGround)
			for(int i = 0; i < 1000; i++)
				mc.thePlayer.sendQueue.addToSendQueue(new C03PacketPlayer());
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
