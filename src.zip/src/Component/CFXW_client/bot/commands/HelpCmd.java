
package component.CFXW_client.bot.commands;

import java.util.Iterator;

import component.CFXW_client.bot.CFXWBot;
import component.CFXW_client.utils.MiscUtils;

@Command.Info(help = "Shows the command list or the help for a command.",
	name = "help",
	syntax = {"[<page>]", "[<command>]"})
public class HelpCmd extends Command
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
		{
			execute(new String[]{"1"});
			return;
		}
		int pages =
			(int)Math.ceil(CFXWBot.getBot().getCommandManager()
				.countCommands() / 8D);
		if(MiscUtils.isInteger(args[0]))
		{
			int page = Integer.valueOf(args[0]);
			if(page > pages || page < 1)
				syntaxError("Invalid page: " + page);
			System.out.println("Available commands: "
				+ CFXWBot.getBot().getCommandManager().countCommands());
			System.out.println("Command list (page " + page + "/" + pages
				+ "):");
			Iterator<Command> itr =
				CFXWBot.getBot().getCommandManager().getAllCommands()
					.iterator();
			for(int i = 0; itr.hasNext(); i++)
			{
				Command cmd = itr.next();
				if(i >= (page - 1) * 8 && i < (page - 1) * 8 + 8)
					System.out.println(cmd.getName());
			}
		}else
		{
			Command cmd =
				CFXWBot.getBot().getCommandManager().getCommandByName(args[0]);
			if(cmd != null)
			{
				System.out.println("Available help for \"" + args[0] + "\":");
				cmd.printHelp();
				cmd.printSyntax();
			}else
				syntaxError();
		}
	}
}
