
package component.CFXW_client.bot.commands;

import component.CFXW_client.utils.MiscUtils;

@Command.Info(help = "Changes the proxy used for server connections. Must be a SOCKS(method) proxy!",
	name = "proxy",
	syntax = {"<ip>:<port>", "none"})
public class ProxyCmd extends Command
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length < 1 || args.length > 2)
			syntaxError();
		if(args[0].contains(":"))
		{
			String ip = args[0].split(":")[0];
			String portSring = args[0].split(":")[1];
			if(!MiscUtils.isInteger(portSring))
				syntaxError("Invalid port: " + portSring);
			try
			{
				System.setProperty("socksProxyHost", ip);
				System.setProperty("socksProxyPort", portSring);
			}catch(Exception e)
			{
				error(e.getMessage());
			}
		}else if(args[0].equalsIgnoreCase("none"))
		{
			System.setProperty("socksProxyHost", "");
			System.setProperty("socksProxyPort", "");
		}else
			syntaxError("Not a proxy: " + args[0]);
		System.out.println("Proxy set to " + args[0]);
	}
}
