
package component.CFXW_client.navigator;

public class PossibleKeybind
{
	private String command;
	private String description;
	
	public PossibleKeybind(String command, String description)
	{
		this.command = command;
		this.description = description;
	}
	
	public String getCommand()
	{
		return command;
	}
	
	public String getDescription()
	{
		return description;
	}
}
