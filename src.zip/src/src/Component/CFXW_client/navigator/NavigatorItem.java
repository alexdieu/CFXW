
package component.CFXW_client.navigator;

import java.util.ArrayList;

import component.CFXW_client.navigator.settings.NavigatorSetting;

public interface NavigatorItem
{
	public String getName();
	
	public String getType();
	
	public String getDescription();
	
	public boolean isEnabled();
	
	public boolean isBlocked();
	
	public String getTags();
	
	public ArrayList<NavigatorSetting> getSettings();
	
	public ArrayList<PossibleKeybind> getPossibleKeybinds();
	
	public String getPrimaryAction();
	
	public void doPrimaryAction();
	
	public String getTutorialPage();
	
	public NavigatorItem[] getSeeAlso();
}
