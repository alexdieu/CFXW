
package component.CFXW_client.mods;


import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.FUN,
	description = "Makes you twerk like Miley Cyrus!",
	name = "Miley Cyrus")
public class MileyCyrusMod extends Mod implements UpdateListener
{
	private int timer;
	
	@Override
	public void onEnable()
	{
		timer = 0;
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		timer++;
		if(timer >= 6)
		{
			mc.gameSettings.keyBindSneak.pressed =
				!mc.gameSettings.keyBindSneak.pressed;
			timer = 0;
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		mc.gameSettings.keyBindSneak.pressed = false;
	}
}
