
package component.CFXW_client.mods;

import net.minecraft.block.Block;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.BLOCKS,
	description = "Automatically mines a block as soon as you look at it.",
	name = "AutoMine")
public class AutoMineMod extends Mod implements UpdateListener
{
	@Override
	public void onEnable()
	{
		mc.gameSettings.keyBindAttack.pressed = false;
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.objectMouseOver == null
			|| mc.objectMouseOver.getBlockPos() == null)
			return;
		if(Block.getIdFromBlock(mc.theWorld.getBlockState(
			mc.objectMouseOver.getBlockPos()).getBlock()) != 0)
			mc.gameSettings.keyBindAttack.pressed = true;
		else
			mc.gameSettings.keyBindAttack.pressed = false;
		
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
		mc.gameSettings.keyBindAttack.pressed = false;
	}
}
