
package component.CFXW_client.mods;

import net.alexdieu.minecraft.gui.component.BoundedRangeComponent.ValueDisplay;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.settings.SliderSetting;

@Info(category = Category.MOVEMENT,
	description = "Changes the speed of almost everything.\n"
		+ "Tip: Slow speeds make aiming easier and work well with\n"
		+ "NoCheat+.",
	name = "Timer")
public class TimerMod extends Mod
{
	public float speed = 2.0F;
	
	@Override
	public void initSettings()
	{
		settings.add(new SliderSetting("Speed", speed, 0.1, 10, 0.1,
			ValueDisplay.DECIMAL)
		{
			@Override
			public void update()
			{
				speed = (float)getValue();
			}
		});
	}
}
