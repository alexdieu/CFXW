
package component.CFXW_client.mods;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;

@Info(category = Category.COMBAT,
	description = "Automatically attacks the entity you're looking at.",
	name = "TriggerBot")
public class TriggerBotMod extends Mod implements UpdateListener
{
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraMod, CFXW.mods.killauraLegitMod,
			CFXW.mods.multiAuraMod, CFXW.mods.clickAuraMod,
			CFXW.mods.criticalsMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraMod.isEnabled())
			CFXW.mods.killauraMod.setEnabled(false);
		if(CFXW.mods.killauraLegitMod.isEnabled())
			CFXW.mods.killauraLegitMod.setEnabled(false);
		if(CFXW.mods.multiAuraMod.isEnabled())
			CFXW.mods.multiAuraMod.setEnabled(false);
		if(CFXW.mods.clickAuraMod.isEnabled())
			CFXW.mods.clickAuraMod.setEnabled(false);
		if(CFXW.mods.tpAuraMod.isEnabled())
			CFXW.mods.tpAuraMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.objectMouseOver != null
			&& mc.objectMouseOver.typeOfHit == MovingObjectType.ENTITY
			&& mc.objectMouseOver.entityHit instanceof EntityLivingBase)
		{
			updateMS();
			boolean yesCheatMode = CFXW.mods.yesCheatMod.isActive();
			if(yesCheatMode
				&& hasTimePassedS(CFXW.mods.killauraMod.yesCheatSpeed)
				|| !yesCheatMode
				&& hasTimePassedS(CFXW.mods.killauraMod.normalSpeed))
			{
				EntityLivingBase en =
					(EntityLivingBase)mc.objectMouseOver.entityHit;
				if((yesCheatMode
					&& mc.thePlayer.getDistanceToEntity(en) <= CFXW.mods.killauraMod.yesCheatRange || !yesCheatMode
					&& mc.thePlayer.getDistanceToEntity(en) <= CFXW.mods.killauraMod.normalRange)
					&& EntityUtils.isCorrectEntity(en, true))
				{
					if(CFXW.mods.autoSwordMod.isActive())
						AutoSwordMod.setSlot();
					CFXW.mods.criticalsMod.doCritical();
					CFXW.mods.blockHitMod.doBlock();
					mc.thePlayer.swingItem();
					mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(
						en, C02PacketUseEntity.Action.ATTACK));
					updateLastMS();
				}
			}
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
