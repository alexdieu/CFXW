
package component.CFXW_client.mods;

import net.minecraft.entity.item.EntityMinecartChest;
import net.minecraft.tileentity.TileEntityChest;
import net.minecraft.tileentity.TileEntityEnderChest;
import component.CFXW_client.events.listeners.RenderListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.RenderUtils;

@Info(category = Category.RENDER,
	description = "Allows you to see chests through walls.",
	name = "ChestESP")
public class ChestEspMod extends Mod implements RenderListener
{
	private int maxChests = 1000;
	public boolean shouldInform = true;
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.mods.itemEspMod, CFXW.mods.searchMod,
			CFXW.mods.xRayMod};
	}
	
	@Override
	public void onEnable()
	{
		shouldInform = true;
		CFXW.events.add(RenderListener.class, this);
	}
	
	@Override
	public void onRender()
	{
		int i = 0;
		for(Object o : mc.theWorld.loadedTileEntityList)
		{
			if(i >= maxChests)
				break;
			if(o instanceof TileEntityChest)
			{
				i++;
				RenderUtils.blockESPBox(((TileEntityChest)o).getPos());
			}else if(o instanceof TileEntityEnderChest)
			{
				i++;
				RenderUtils.blockESPBox(((TileEntityEnderChest)o).getPos());
			}
		}
		for(Object o : mc.theWorld.loadedEntityList)
		{
			if(i >= maxChests)
				break;
			if(o instanceof EntityMinecartChest)
			{
				i++;
				RenderUtils.blockESPBox(((EntityMinecartChest)o).getPosition());
			}
		}
		if(i >= maxChests && shouldInform)
		{
			CFXW.chat.warning(getName() + " found �lA LOT�r of chests.");
			CFXW.chat.message("To prevent lag, it will only show the first "
				+ maxChests + " chests.");
			shouldInform = false;
		}else if(i < maxChests)
			shouldInform = true;
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(RenderListener.class, this);
	}
}
