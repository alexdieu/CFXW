
package component.CFXW_client.mods;

import net.minecraft.client.gui.GuiScreen;
import component.CFXW_client.events.listeners.DeathListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.COMBAT,
	description = "Automatically respawns you whenever you die.",
	name = "AutoRespawn")
public class AutoRespawnMod extends Mod implements DeathListener
{
	@Override
	public void onEnable()
	{
		CFXW.events.add(DeathListener.class, this);
	}
	
	@Override
	public void onDeath()
	{
		mc.thePlayer.respawnPlayer();
		GuiScreen.mc.displayGuiScreen((GuiScreen)null);
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(DeathListener.class, this);
	}
}
