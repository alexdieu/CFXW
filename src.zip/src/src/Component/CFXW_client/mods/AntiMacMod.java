
package component.CFXW_client.mods;

import java.util.HashSet;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Makes other mods bypass Mineplex AntiCheat or blocks them\n"
		+ "if they can't.",
	name = "AntiMAC")
public class AntiMacMod extends Mod
{
	private HashSet<Mod> blockedMods;
	
	@Override
	public void onEnable()
	{
		if(CFXW.mods.yesCheatMod.isEnabled())
			CFXW.mods.yesCheatMod.setEnabled(false);
		if(blockedMods == null)
		{
			blockedMods = new HashSet<>();
			// add mods that down't work with YesCheat+
			for(Mod mod : CFXW.mods.getAllMods())
				if(!mod.getClass().getAnnotation(Mod.Info.class)
					.noCheatCompatible())
					blockedMods.add(mod);
			
			// remove mods that work with MAC
			// TODO: More efficient method to do this
			blockedMods.remove(CFXW.mods.antiFireMod);
			blockedMods.remove(CFXW.mods.antiPotionMod);
			blockedMods.remove(CFXW.mods.fastBowMod);
			blockedMods.remove(CFXW.mods.glideMod);
			blockedMods.remove(CFXW.mods.multiAuraMod);
			blockedMods.remove(CFXW.mods.noSlowdownMod);
			blockedMods.remove(CFXW.mods.regenMod);
			blockedMods.remove(CFXW.mods.spiderMod);
			blockedMods.remove(CFXW.mods.tpAuraMod);
			
			// block FancyChat because Mineplex disables special characters
			blockedMods.add(CFXW.mods.fancyChatMod);
		}
		for(Mod mod : blockedMods)
			mod.setBlocked(true);
	}
	
	@Override
	public void onDisable()
	{
		for(Mod mod : blockedMods)
			mod.setBlocked(false);
	}
}
