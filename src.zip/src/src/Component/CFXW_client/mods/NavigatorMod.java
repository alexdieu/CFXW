
package component.CFXW_client.mods;

import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;
import component.CFXW_client.navigator.gui.NavigatorMainScreen;

@Info(category = Category.HIDDEN, description = "", name = "Navigator")
public class NavigatorMod extends Mod
{
	@Override
	public void onEnable()
	{
		if(!(mc.currentScreen instanceof NavigatorMainScreen))
			mc.displayGuiScreen(new NavigatorMainScreen());
		setEnabled(false);
	}
}
