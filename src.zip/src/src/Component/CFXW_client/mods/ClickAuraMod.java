
package component.CFXW_client.mods;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.network.play.client.C02PacketUseEntity;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.utils.EntityUtils;

@Mod.Info(category = Mod.Category.COMBAT,
	description = "Automatically attacks the closest valid entity whenever you\n"
		+ "click.\n"
		+ "Warning: ClickAuras generally look more suspicious than Killauras\n"
		+ "and are easier to detect. It is recommended to use Killaura or\n"
		+ "TriggerBot instead.",
	name = "ClickAura",
	tags = "Click Aura,ClickAimbot,Click Aimbot")
public class ClickAuraMod extends Mod implements UpdateListener
{
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[]{CFXW.special.targetSpf,
			CFXW.mods.killauraMod, CFXW.mods.killauraLegitMod,
			CFXW.mods.multiAuraMod, CFXW.mods.triggerBotMod};
	}
	
	@Override
	public void onEnable()
	{
		// TODO: Clean up this mess!
		if(CFXW.mods.killauraMod.isEnabled())
			CFXW.mods.killauraMod.setEnabled(false);
		if(CFXW.mods.killauraLegitMod.isEnabled())
			CFXW.mods.killauraLegitMod.setEnabled(false);
		if(CFXW.mods.multiAuraMod.isEnabled())
			CFXW.mods.multiAuraMod.setEnabled(false);
		if(CFXW.mods.triggerBotMod.isEnabled())
			CFXW.mods.triggerBotMod.setEnabled(false);
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		updateMS();
		EntityLivingBase en = EntityUtils.getClosestEntity(true, true);
		if(hasTimePassedS(CFXW.mods.killauraMod.realSpeed) && en != null
			&& mc.gameSettings.keyBindAttack.pressed)
			if(mc.thePlayer.getDistanceToEntity(en) <= CFXW.mods.killauraMod.realRange)
			{
				if(CFXW.mods.autoSwordMod.isActive())
					AutoSwordMod.setSlot();
				CFXW.mods.criticalsMod.doCritical();
				CFXW.mods.blockHitMod.doBlock();
				EntityUtils.faceEntityPacket(en);
				mc.thePlayer.swingItem();
				mc.thePlayer.sendQueue.addToSendQueue(new C02PacketUseEntity(
					en, C02PacketUseEntity.Action.ATTACK));
				updateLastMS();
			}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
}
