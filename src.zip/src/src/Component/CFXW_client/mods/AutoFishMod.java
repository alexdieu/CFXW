
package component.CFXW_client.mods;

import net.minecraft.entity.projectile.EntityFishHook;
import component.CFXW_client.events.listeners.UpdateListener;
import component.CFXW_client.mods.Mod.Category;
import component.CFXW_client.mods.Mod.Info;

@Info(category = Category.MISC,
	description = "Automatically catches fish.",
	name = "AutoFish")
public class AutoFishMod extends Mod implements UpdateListener
{
	private boolean catching = false;
	
	@Override
	public void onEnable()
	{
		CFXW.events.add(UpdateListener.class, this);
	}
	
	@Override
	public void onUpdate()
	{
		if(mc.thePlayer.fishEntity != null && isHooked(mc.thePlayer.fishEntity)
			&& !catching)
		{
			catching = true;
			mc.rightClickMouse();
			new Thread("AutoFish")
			{
				@Override
				public void run()
				{
					try
					{
						Thread.sleep(1000);
					}catch(InterruptedException e)
					{
						e.printStackTrace();
					}
					mc.rightClickMouse();
					catching = false;
				}
			}.start();
		}
	}
	
	@Override
	public void onDisable()
	{
		CFXW.events.remove(UpdateListener.class, this);
	}
	
	private boolean isHooked(EntityFishHook hook)
	{
		return hook.motionX == 0.0D && hook.motionZ == 0.0D
			&& hook.motionY != 0.0D;
	}
}
