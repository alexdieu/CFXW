
package Component.CFXW_client.update;

public class Print {


	public static void main(String [] args){
		System.out.print("Couldn't update , don't worry , this feature will be implemented soon by alexdieu !");
		System.out.print("Couldn't update , don't worry , this feature will be implemented soon by alexdieu !");
	}

}

