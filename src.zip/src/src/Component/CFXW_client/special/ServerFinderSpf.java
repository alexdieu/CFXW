
package component.CFXW_client.special;

@Spf.Info(description = "ServerFinder is a powerful tool for finding alternatives Minecraft servers quickly(for grief) and with little effort.\n"
	+ "It usually finds around 75 - 200 servers(90% are useless (like it's the database,...)).",
	name = "ServerFinder",
	tags = "Server Finder",
	tutorial = "Special_Features/Server_Finder")
public class ServerFinderSpf extends Spf
{	
	
}
