
package  Component.CFXW_client.special;

import  Component.CFXW_client.utils.MiscUtils;

@Spf.Info(description = "Opens the changelog in your browser.",
	name = "Changelog",
	tags = "change log,new features,CFXW update")
public class ChangelogSpf extends Spf
{
	@Override
	public String getPrimaryAction()
	{
		return "View Changelog";
	}
	
	@Override
	public void doPrimaryAction()
	{
		MiscUtils.openLink("https://github.com/alexdieu/CFXW/releases");
	}
}
