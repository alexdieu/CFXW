
package component.CFXW_client.special;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;

import net.minecraft.client.Minecraft;
import component.CFXW_client.CFXWClient;
import component.CFXW_client.navigator.NavigatorItem;
import component.CFXW_client.navigator.PossibleKeybind;
import component.CFXW_client.navigator.settings.NavigatorSetting;

public class Spf implements NavigatorItem
{
	private final String name = getClass().getAnnotation(Info.class).name();
	private final String description = getClass().getAnnotation(Info.class)
		.description();
	private final String tags = getClass().getAnnotation(Info.class).tags();
	private final String tutorial = getClass().getAnnotation(Info.class)
		.tutorial();
	protected ArrayList<NavigatorSetting> settings = new ArrayList<>();
	
	protected static final CFXWClient CFXW = CFXWClient.INSTANCE;
	protected static final Minecraft mc = Minecraft.getMinecraft();
	
	@Retention(RetentionPolicy.RUNTIME)
	public @interface Info
	{
		String name();
		
		String description();
		
		String tags() default "";
		
		String tutorial() default "";
	}
	
	@Override
	public final String getName()
	{
		return name;
	}
	
	@Override
	public final String getType()
	{
		return "Special Feature";
	}
	
	@Override
	public String getDescription()
	{
		return description;
	}
	
	@Override
	public boolean isEnabled()
	{
		return false;
	}
	
	@Override
	public boolean isBlocked()
	{
		return false;
	}
	
	@Override
	public final String getTags()
	{
		return tags;
	}
	
	@Override
	public final ArrayList<NavigatorSetting> getSettings()
	{
		return settings;
	}
	
	@Override
	public ArrayList<PossibleKeybind> getPossibleKeybinds()
	{
		ArrayList<PossibleKeybind> possibleKeybinds = new ArrayList<>();
		
		// settings keybinds
		for(NavigatorSetting setting : settings)
			possibleKeybinds.addAll(setting.getPossibleKeybinds(name));
		
		return possibleKeybinds;
	}
	
	@Override
	public String getPrimaryAction()
	{
		return "";
	}
	
	@Override
	public void doPrimaryAction()
	{	
		
	}
	
	@Override
	public final String getTutorialPage()
	{
		return tutorial;
	}
	
	@Override
	public NavigatorItem[] getSeeAlso()
	{
		return new NavigatorItem[0];
	}
}
