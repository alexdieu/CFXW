
package component.CFXW_client.commands;

import net.minecraft.block.Block;
import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Changes the settings of Search or toggles it.",
	name = "search",
	syntax = {"id <block_id>", "name <block_name>"})
public class SearchCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
		{
			CFXW.mods.searchMod.toggle();
			CFXW.chat.message("Search turned "
				+ (CFXW.mods.searchMod.isEnabled() == true ? "on" : "off")
				+ ".");
		}else if(args.length == 2)
		{
			if(args[0].toLowerCase().equals("id"))
			{
				if(MiscUtils.isInteger(args[1]))
					CFXW.options.searchID = Integer.valueOf(args[1]);
				else
					syntaxError("ID must be a number.");
				CFXW.files.saveOptions();
				CFXW.mods.searchMod.notify = true;
				CFXW.chat.message("Search ID set to " + args[1] + ".");
			}else if(args[0].equalsIgnoreCase("name"))
			{
				int newID =
					Block.getIdFromBlock(Block.getBlockFromName(args[1]));
				if(newID == -1)
					error("Block \"" + args[1] + "\" could not be found.");
				CFXW.options.searchID = Integer.valueOf(newID);
				CFXW.files.saveOptions();
				CFXW.mods.searchMod.notify = true;
				CFXW.chat.message("Search ID set to " + newID + " (" + args[1]
					+ ").");
			}
		}else
			syntaxError();
	}
}
