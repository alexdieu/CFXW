
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Changes the amount of Throw or toggles it.",
	name = "throw",
	syntax = {"[amount <amount>]"})
public class ThrowCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
		{
			CFXW.mods.throwMod.toggle();
			CFXW.chat.message("Throw turned "
				+ (CFXW.mods.throwMod.isEnabled() == true ? "on" : "off")
				+ ".");
		}else if(args.length == 2 && args[0].equalsIgnoreCase("amount")
			&& MiscUtils.isInteger(args[1]))
		{
			if(Integer.valueOf(args[1]) < 1)
			{
				CFXW.chat.error("Throw amount must be at least 1.");
				return;
			}
			CFXW.options.throwAmount = Integer.valueOf(args[1]);
			CFXW.files.saveOptions();
			CFXW.chat.message("Throw amount set to " + args[1] + ".");
		}else
			syntaxError();
	}
}
