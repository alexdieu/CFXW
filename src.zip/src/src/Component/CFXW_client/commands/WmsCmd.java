
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Enables/disables CFXW messages or sends a message.",
	name = "wms",
	syntax = {"(on | off)", "echo <message>"})
public class WmsCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
			syntaxError();
		if(args[0].equalsIgnoreCase("on") || args[0].equalsIgnoreCase("off"))
			wurst.chat.setEnabled(args[0].equalsIgnoreCase("on"));
		else if(args[0].equalsIgnoreCase("echo") && args.length == 2)
		{
			String message = args[1];
			for(int i = 2; i < args.length; i++)
				message += " " + args[i];
			wurst.chat.cmd(message);
		}else
			syntaxError();
	}
}
