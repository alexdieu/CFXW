
package component.CFXW_client.commands;

import net.minecraft.entity.EntityLivingBase;
import component.CFXW_client.utils.EntityUtils;

@Cmd.Info(help = "Toggles Protect or makes it protect a specific entity.",
	name = "protect",
	syntax = {"[<entity>]"})
public class ProtectCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length > 1)
			syntaxError();
		if(args.length == 0)
			CFXW.mods.protectMod.toggle();
		else
		{
			if(CFXW.mods.protectMod.isEnabled())
				CFXW.mods.protectMod.setEnabled(false);
			EntityLivingBase entity = EntityUtils.searchEntityByName(args[0]);
			if(entity == null)
				error("Entity \"" + args[0] + "\" could not be found.");
			CFXW.mods.protectMod.setEnabled(true);
			CFXW.mods.protectMod.setFriend(entity);
		}
	}
}
