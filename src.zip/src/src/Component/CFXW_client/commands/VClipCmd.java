
package component.CFXW_client.commands;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Teleports you up/down. Can glitch you through floors & "
	+ "ceilings.\nThe maximum distance is 100 blocks on vanilla servers and "
	+ "10 blocks on Bukkit servers.", name = "vclip", syntax = {"<height>"})
public class VClipCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 1)
			syntaxError();
		if(MiscUtils.isInteger(args[0]))
			mc.thePlayer.setPosition(mc.thePlayer.posX, mc.thePlayer.posY
				+ Integer.valueOf(args[0]), mc.thePlayer.posZ);
		else
			syntaxError();
	}
}
