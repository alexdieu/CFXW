
package component.CFXW_client.commands;

import java.util.Iterator;

import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.utils.MiscUtils;

@Info(help = "Shows the command list or the help for a command.",
	name = "help",
	syntax = {"[<page>]", "[<command>]"})
public class HelpCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
		{
			execute(new String[]{"1"});
			return;
		}
		int pages = (int)Math.ceil(CFXW.commands.countCommands() / 8D);
		if(MiscUtils.isInteger(args[0]))
		{
			int page = Integer.valueOf(args[0]);
			if(page > pages || page < 1)
				syntaxError("Invalid page: " + page);
			CFXW.chat.message("Available commands: "
				+ CFXW.commands.countCommands());
			CFXW.chat.message("Command list (page " + page + "/" + pages
				+ "):");
			Iterator<Cmd> itr = CFXW.commands.getAllCommands().iterator();
			for(int i = 0; itr.hasNext(); i++)
			{
				Cmd cmd = itr.next();
				if(i >= (page - 1) * 8 && i < (page - 1) * 8 + 8)
					CFXW.chat.message(cmd.getCmdName());
			}
		}else
		{
			Cmd cmd = CFXW.commands.getCommandByName(args[0]);
			if(cmd != null)
			{
				CFXW.chat.message("Available help for ." + args[0] + ":");
				cmd.printHelp();
				cmd.printSyntax();
			}else
				error("Command \"" + args[0] + "\" could not be found.");
		}
	}
}
