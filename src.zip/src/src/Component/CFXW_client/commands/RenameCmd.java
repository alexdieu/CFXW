
package component.CFXW_client.commands;

import net.minecraft.item.ItemStack;
import component.CFXW_client.commands.Cmd.Info;

@Info(help = "Renames the item in your hand. Use $ for colors, use $$ for $.",
	name = "rename",
	syntax = {"<new_name>"})
public class RenameCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(!mc.thePlayer.capabilities.isCreativeMode)
			error("Creative mode only.");
		if(args.length == 0)
			syntaxError();
		String message = args[0];
		for(int i = 1; i < args.length; i++)
			message += " " + args[i];
		message = message.replace("$", "�").replace("��", "$");
		ItemStack item = mc.thePlayer.inventory.getCurrentItem();
		if(item == null)
			error("There is no item in your hand.");
		item.setStackDisplayName(message);
		CFXW.chat.message("Renamed item to \"" + message + "�r\".");
	}
}
