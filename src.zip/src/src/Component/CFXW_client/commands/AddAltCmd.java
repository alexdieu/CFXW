
package component.CFXW_client.commands;

import java.util.Iterator;

import net.minecraft.client.network.NetworkPlayerInfo;
import net.minecraft.util.StringUtils;
import component.CFXW_client.alts.Alt;
import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.gui.alts.GuiAltList;

@Info(help = "Adds a player or all players on a server to your alt list.",
	name = "addalt",
	syntax = {"<player>", "all"})
public class AddAltCmd extends Cmd
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 1)
			syntaxError();
		if(args[0].equals("all"))
		{
			int alts = 0;
			Iterator itr = mc.getNetHandler().getPlayerInfo().iterator();
			while(itr.hasNext())
			{
				NetworkPlayerInfo info = (NetworkPlayerInfo)itr.next();
				String crackedName =
					StringUtils.stripControlCodes(info.getPlayerNameForReal());
				if(crackedName.equals(mc.thePlayer.getName())
					|| crackedName.equals("All")
					|| GuiAltList.alts.contains(new Alt(crackedName)))
					continue;
				GuiAltList.alts.add(new Alt(crackedName));
				alts++;
			}
			if(alts == 1)
				CFXW.chat.message("Added 1 alt to the alt list.");
			else
				CFXW.chat.message("Added " + alts + " alts to the alt list.");
			GuiAltList.sortAlts();
			CFXW.files.saveAlts();
		}else if(!args[0].equals("Alexander01998"))
		{
			GuiAltList.alts.add(new Alt(args[0]));
			GuiAltList.sortAlts();
			CFXW.files.saveAlts();
			CFXW.chat.message("Added \"" + args[0] + "\" to the alt list.");
		}
	}
}
