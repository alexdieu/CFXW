
package component.CFXW_client.commands;

import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.client.gui.inventory.GuiInventory;
import component.CFXW_client.commands.Cmd.Info;
import component.CFXW_client.events.listeners.RenderListener;

@Info(help = "Allows you to see parts of another player's inventory.",
	name = "invsee",
	syntax = {"<player>"})
public class InvseeCmd extends Cmd implements RenderListener
{
	private String playerName;
	
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 1)
			syntaxError();
		if(mc.thePlayer.capabilities.isCreativeMode)
		{
			CFXW.chat.error("Survival mode only.");
			return;
		}
		playerName = args[0];
		CFXW.events.add(RenderListener.class, this);
	}
	
	@Override
	public void onRender()
	{
		boolean found = false;
		for(Object entity : mc.theWorld.loadedEntityList)
			if(entity instanceof EntityOtherPlayerMP)
			{
				EntityOtherPlayerMP player = (EntityOtherPlayerMP)entity;
				if(player.getName().equals(playerName))
				{
					CFXW.chat.message("Showing inventory of "
						+ player.getName() + ".");
					mc.displayGuiScreen(new GuiInventory(player));
					found = true;
				}
			}
		if(!found)
			CFXW.chat.error("Player not found.");
		playerName = null;
		CFXW.events.remove(RenderListener.class, this);
	}
}
