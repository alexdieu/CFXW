
package component.CFXW_client.bot.commands;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.GuiConnecting;
import net.minecraft.client.multiplayer.ServerData;
import component.CFXW_client.gui.main.GuiCFXWMainMenu;

@Command.Info(help = "Joins a server.", name = "join", syntax = {"<ip>"})
public class JoinCmd extends Command
{
	@Override
	public void execute(final String[] args) throws Error
	{
		if(args.length != 1)
			syntaxError();
		Minecraft.getMinecraft().addScheduledTask(new Runnable()
		{
			@Override
			public void run()
			{
				Minecraft.getMinecraft().displayGuiScreen(
					new GuiConnecting(new GuiCFXWMainMenu(), Minecraft
						.getMinecraft(), new ServerData("", args[0])));
				System.out.println("Joined " + args[0] + " as "
					+ Minecraft.getMinecraft().session.getUsername());
			}
		});
	}
}
