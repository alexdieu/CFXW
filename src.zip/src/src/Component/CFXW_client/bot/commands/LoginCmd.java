
package component.CFXW_client.bot.commands;

import net.minecraft.client.Minecraft;
import component.CFXW_client.alts.LoginManager;

@Command.Info(help = "Logs you in with a premium or cracked(NO TOKEN!TO GENERATE ALTS YOU CAN GO ON INTERNET) account.",
	name = "login",
	syntax = {"<email> <password>", "<name>"})
public class LoginCmd extends Command
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length < 1 || args.length > 2)
			syntaxError();
		if(args.length == 1)
		{
			LoginManager.changeCrackedName(args[0]);
			System.out.println("Changed name to \"" + args[0] + "\".");
		}else
		{
			String error = LoginManager.login(args[0], args[1]);
			if(error.isEmpty())
				System.out.println("Logged in as "
					+ Minecraft.getMinecraft().session.getUsername());
			else
				error(error);
		}
	}
}
