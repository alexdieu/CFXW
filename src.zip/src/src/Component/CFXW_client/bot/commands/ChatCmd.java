
package component.CFXW_client.bot.commands;

import net.minecraft.client.Minecraft;

@Command.Info(help = "Sends a chat message. Can be used to run CFXW commands.",
	name = "chat",
	syntax = {"<message>"})
public class ChatCmd extends Command
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length == 0)
			syntaxError();
		if(Minecraft.getMinecraft().thePlayer == null)
			error("Not connected to any server.");
		String message = args[0];
		for(int i = 1; i < args.length; i++)
			message += " " + args[i];
		Minecraft.getMinecraft().thePlayer.sendChatMessage(message);
	}
}
