
package component.CFXW_client.commands;

import net.minecraft.client.Minecraft;

@Command.Info(help = "Stops CFXW-Bot.", name = "stop", syntax = {})
public class StopCmd extends Command
{
	@Override
	public void execute(String[] args) throws Error
	{
		if(args.length != 0)
			syntaxError();
		System.out.println("Stopping CFXW-Bot...");
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable()
		{
			@Override
			public void run()
			{
				System.out.println("CFXW-Bot forced stop succesfully.");
			}
		}));
		Minecraft.getMinecraft().shutdown();
	}
}
