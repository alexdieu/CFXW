
package component.CFXW_client.chat;

import net.minecraft.client.Minecraft;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.IChatComponent;

public class ChatManager
{
	private boolean enabled = true;
	
	public void setEnabled(boolean enabled)
	{
		this.enabled = enabled;
	}
	
	public void component(IChatComponent component)
	{
		if(enabled)
			Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(
				new ChatComponentText("�c[�6CFXW�c]�f ")
					.appendSibling(component));
	}
	
	public void message(String message)
	{
		component(new ChatComponentText(message));
	}
	
	public void info(String message)
	{
		message("�8[�7�lINFO�8]�f " + message);
	}
	
	public void debug(String message)
	{
		message("�8[�7�lDEBUG-INFO�8]�f " + message);
	}
	
	public void warning(String message)
	{
		message("�c[�6�lWARNING�c]�f " + message);
	}
	
	public void error(String message)
	{
		message("�c[�4�lERROR�c]�f " + message);
	}
	
	public void success(String message)
	{
		message("�a[�2�lSUCCESS�a]�f " + message);
	}
	
	public void failure(String message)
	{
		message("�c[�4�lFAILURE�c]�f " + message);
	}
	
	public void cmd(String message)
	{
		Minecraft.getMinecraft().ingameGUI.getChatGUI().printChatMessage(
			new ChatComponentText("�c[�6CFXW�c]�f �0�l<�aCMD�0�l>�f "
				+ message));
	}
}
