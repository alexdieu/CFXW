package net.alexdieu.minecraft.gui.component;

public interface RadioButton extends Button, SelectableComponent
{}
