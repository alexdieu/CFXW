package net.alexdieu.minecraft.gui.component;

import net.alexdieu.minecraft.gui.listener.ButtonListener;

import Component.CFXW_client.mods.Mod;

public interface Button extends Component, TextComponent
{
	public void press();
	
	public void addButtonListener(ButtonListener listener);
	
	public void removeButtonListener(ButtonListener listener);
	
	public ButtonGroup getGroup();
	
	public void setGroup(ButtonGroup group);
	
	public String getDescription();
	
	public Mod getMod();
}
