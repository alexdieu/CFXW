package net.alexdieu.minecraft.gui.listener;

import net.alexdieu.minecraft.gui.component.ComboBox;

public interface ComboBoxListener extends ComponentListener
{
	public void onComboBoxSelectionChanged(ComboBox comboBox);
}
