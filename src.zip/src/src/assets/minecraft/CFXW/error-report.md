> This is an auto-generated error report for the [CFXW Client](https://github.com/alexdieu).

# Description
�desc

# Stacktrace
```
�trace
```

# System details
- OS: �os
- Java version: �java
- CFXW version: �cfxw
- Timestamp: �time