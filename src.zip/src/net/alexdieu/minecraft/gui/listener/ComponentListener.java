package net.alexdieu.minecraft.gui.listener;

public interface ComponentListener
{	
	
}
