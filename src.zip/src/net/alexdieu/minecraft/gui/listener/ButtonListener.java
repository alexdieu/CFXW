package net.alexdieu.minecraft.gui.listener;

import net.alexdieu.minecraft.gui.component.Button;

public interface ButtonListener extends ComponentListener
{
	public void onButtonPress(Button button);
}
