package net.alexdieu.minecraft.gui.listener;

import net.alexdieu.minecraft.gui.component.Slider;

public interface SliderListener extends ComponentListener
{
	public void onSliderValueChanged(Slider slider);
}
