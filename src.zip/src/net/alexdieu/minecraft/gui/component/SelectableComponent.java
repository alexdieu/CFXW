package net.alexdieu.minecraft.gui.component;

import net.alexdieu.minecraft.gui.listener.SelectableComponentListener;

public interface SelectableComponent extends Component
{
	public boolean isSelected();
	
	public void setSelected(boolean selected);
	
	public void addSelectableComponentListener(
		SelectableComponentListener listener);
	
	public void removeSelectableComponentListener(
		SelectableComponentListener listener);
}
