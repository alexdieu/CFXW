package net.alexdieu.minecraft.gui.component;

public interface Panel extends Container
{}
