package net.alexdieu.minecraft.gui.component;

public interface CheckButton extends Button, SelectableComponent
{}
