package net.alexdieu.minecraft.gui.component.basic;

import net.alexdieu.minecraft.gui.component.AbstractContainer;
import net.alexdieu.minecraft.gui.component.Panel;
import net.alexdieu.minecraft.gui.layout.LayoutManager;

public class BasicPanel extends AbstractContainer implements Panel
{
	public BasicPanel()
	{}
	
	public BasicPanel(LayoutManager layoutManager)
	{
		setLayoutManager(layoutManager);
	}
}
