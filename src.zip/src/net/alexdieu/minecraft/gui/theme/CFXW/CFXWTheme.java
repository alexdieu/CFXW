
package net.alexdieu.minecraft.gui.theme.wurst;

import net.minecraft.client.gui.FontRenderer;

import net.alexdieu.minecraft.gui.theme.AbstractTheme;

import Component.CFXW_client.font.Fonts;

public class CFXWTheme extends AbstractTheme
{
	private final FontRenderer fontRenderer;
	
	public CFXWTheme()
	{
		fontRenderer = Fonts.segoe15;
		
		installUI(new CFXWFrameUI(this));
		installUI(new CFXWPanelUI(this));
		installUI(new CFXWLabelUI(this));
		installUI(new CFXWButtonUI(this));
		installUI(new CFXWCheckButtonUI(this));
		installUI(new CFXWComboBoxUI(this));
		installUI(new CFXWSliderUI(this));
		installUI(new CFXWProgressBarUI(this));
	}
	
	public FontRenderer getFontRenderer()
	{
		return fontRenderer;
	}
}
