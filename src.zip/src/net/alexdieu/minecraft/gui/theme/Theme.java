package net.alexdieu.minecraft.gui.theme;

import net.alexdieu.minecraft.gui.component.Component;

public interface Theme
{
	public ComponentUI getUIForComponent(Component component);
}
