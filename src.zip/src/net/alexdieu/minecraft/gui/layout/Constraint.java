package net.alexdieu.minecraft.gui.layout;

public interface Constraint
{	
	
}
